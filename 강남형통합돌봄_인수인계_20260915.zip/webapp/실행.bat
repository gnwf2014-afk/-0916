@echo off
chcp 65001 >nul
REM 강남형 통합돌봄 웹앱 실행 (Windows: 더블클릭)
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 가 설치되어 있지 않습니다. https://nodejs.org 에서 LTS 버전을 설치한 뒤 다시 실행하세요.
  pause
  exit /b 1
)
if "%PORT%"=="" set PORT=3000
start "" "http://localhost:%PORT%"
node run.mjs
