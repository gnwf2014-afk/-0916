// 강남형 통합돌봄 웹앱 - 로컬 실행 서버
// Cloudflare Workers용으로 빌드된 server/index.mjs 를 Node.js 에서 그대로 구동합니다.
//   node run.mjs             (기본 포트 3000)
//   PORT=8080 node run.mjs   (포트 지정)
//   NEWS_AUTO=0 node run.mjs (정보나눔 자동 수집 끄기)
//
// 동작 순서 (Cloudflare 배포 환경과 동일하게 맞춤)
//   1. public/ 폴더에 요청 경로와 같은 파일이 있으면 그대로 제공 (/news → public/news/index.html)
//   2. 없으면 서버 렌더링 앱(server/index.mjs)에 넘김
// 정보나눔(보건복지부 보도자료)은 서버 시작 직후와 이후 24시간마다 자동 수집합니다.
import http from "node:http";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Readable } from "node:stream";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, "public");
const PORT = Number(process.env.PORT) || 3000;
// HOST 미지정 시 IPv4/IPv6 모두(localhost, 127.0.0.1, ::1) 수신
const HOST = process.env.HOST || undefined;
const NEWS_AUTO = process.env.NEWS_AUTO !== "0";
const NEWS_INTERVAL_MS = 24 * 60 * 60 * 1000;

const MIME = {
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".txt": "text/plain; charset=utf-8",
  ".xml": "application/xml; charset=utf-8",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
};

/** 요청 경로에 해당하는 public/ 파일을 찾음 (없으면 null). 디렉터리나 확장자 없는 경로는 index.html 을 시도 */
async function resolvePublicFile(pathname) {
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { return null; }
  const candidates = [rel];
  if (rel.endsWith("/")) candidates.push(rel + "index.html");
  else if (!path.extname(rel)) candidates.push(rel + "/index.html", rel + ".html");
  for (const c of candidates) {
    const filePath = path.normalize(path.join(PUBLIC_DIR, c));
    if (!filePath.startsWith(PUBLIC_DIR + path.sep)) continue;
    try {
      const info = await stat(filePath);
      if (info.isFile()) return { filePath, info, rel: c };
    } catch { /* 다음 후보 */ }
  }
  return null;
}
function fileResponse({ filePath, info, rel }, method) {
  const headers = {
    "content-type": MIME[path.extname(filePath).toLowerCase()] || "application/octet-stream",
    "content-length": String(info.size),
  };
  if (rel.startsWith("/assets/")) headers["cache-control"] = "public, max-age=31536000, immutable";
  else if (rel.endsWith(".json")) headers["cache-control"] = "no-cache";
  if (method === "HEAD") return new Response(null, { status: 200, headers });
  return new Response(Readable.toWeb(createReadStream(filePath)), { status: 200, headers });
}

// Cloudflare 의 ASSETS 바인딩을 흉내내는 정적 파일 서버 (public/ 폴더)
const ASSETS = {
  async fetch(request) {
    const found = await resolvePublicFile(new URL(request.url).pathname);
    return found ? fileResponse(found, request.method) : new Response("Not Found", { status: 404 });
  },
};

const { default: worker } = await import("./server/index.mjs");

const env = { ASSETS };
const makeContext = () => ({
  waitUntil(p) { Promise.resolve(p).catch((e) => console.error("[waitUntil]", e)); },
  passThroughOnException() {},
});

function toWebRequest(req) {
  const url = `http://${req.headers.host || `localhost:${PORT}`}${req.url}`;
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) {
    if (v === undefined) continue;
    if (Array.isArray(v)) v.forEach((x) => headers.append(k, x));
    else headers.set(k, v);
  }
  headers.set("cf-connecting-ip", req.socket.remoteAddress || "127.0.0.1");
  const hasBody = !["GET", "HEAD"].includes(req.method);
  return new Request(url, {
    method: req.method,
    headers,
    body: hasBody ? Readable.toWeb(req) : undefined,
    duplex: hasBody ? "half" : undefined,
  });
}

async function sendResponse(res, webRes) {
  const headers = {};
  webRes.headers.forEach((v, k) => {
    if (k === "set-cookie") return;
    headers[k] = v;
  });
  const cookies = webRes.headers.getSetCookie?.() ?? [];
  if (cookies.length) headers["set-cookie"] = cookies;
  res.writeHead(webRes.status, webRes.statusText, headers);
  if (!webRes.body) return res.end();
  Readable.fromWeb(webRes.body).pipe(res);
}

const server = http.createServer(async (req, res) => {
  try {
    // 1) 정적 파일 우선 (Cloudflare 의 assets 처리 순서와 동일)
    if (req.method === "GET" || req.method === "HEAD") {
      const found = await resolvePublicFile(new URL(req.url, "http://localhost").pathname);
      if (found) return await sendResponse(res, fileResponse(found, req.method));
    }
    // 2) 서버 렌더링 앱
    const webRes = await worker.fetch(toWebRequest(req), env, makeContext());
    await sendResponse(res, webRes);
  } catch (err) {
    console.error(err);
    if (!res.headersSent) res.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
    res.end("Internal Server Error");
  }
});

server.listen(PORT, HOST, () => {
  const shown = !HOST || HOST === "0.0.0.0" || HOST === "::" ? "localhost" : HOST;
  console.log(`\n  강남형 통합돌봄 웹앱 실행 중\n  ➜  http://${shown}:${PORT}\n\n  종료: Ctrl + C\n`);
  if (NEWS_AUTO) scheduleNews();
  else console.log("  정보나눔 자동 수집: 꺼짐 (NEWS_AUTO=0)\n");
});

// ───────── 정보나눔 자동 수집 (하루 1회) ─────────
function scheduleNews() {
  const run = async (label) => {
    try {
      const { updateNews } = await import("./tools/fetch-news.mjs");
      const stamp = () => new Date().toLocaleString("ko-KR", { hour12: false });
      await updateNews({ log: (m) => console.log(`  [정보나눔 ${label} ${stamp()}] ${m}`) });
    } catch (e) {
      console.error(`  [정보나눔] 수집 실패 (기존 목록 유지): ${e.message}`);
    }
  };
  setTimeout(() => run("시작"), 3000);
  setInterval(() => run("정기"), NEWS_INTERVAL_MS).unref();
  console.log("  정보나눔 자동 수집: 켜짐 (시작 3초 후, 이후 24시간마다)\n");
}
