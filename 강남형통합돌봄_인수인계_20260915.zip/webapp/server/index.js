globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/map-gangnam-GZNHP2V0.jpg": {
		"type": "image/jpeg",
		"etag": "\"bbc8-+09pMzkZH06yWozWK/BIFX0XH7o\"",
		"mtime": "2026-08-03T04:52:28.539Z",
		"size": 48072,
		"path": "../public/assets/map-gangnam-GZNHP2V0.jpg"
	},
	"/assets/index-r49PEGRW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54dea-iFmBxcQhGdFyP7ZmjHvl/CvO5R0\"",
		"mtime": "2026-09-15T07:39:19.660Z",
		"size": 347626,
		"path": "../public/assets/index-r49PEGRW.js"
	},
	"/assets/map-gangnam-r49PEGRW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ed50-5VnS2BM32Pqooc7qdAJesnyVBvU\"",
		"mtime": "2026-09-15T07:39:19.660Z",
		"size": 60752,
		"path": "../public/assets/map-gangnam-r49PEGRW.js"
	},
	"/assets/routes-r49PEGRW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1856d-7IPhP/cFkjbZCWCz3EkI5j+YrAg\"",
		"mtime": "2026-09-15T07:39:19.660Z",
		"size": 99693,
		"path": "../public/assets/routes-r49PEGRW.js"
	},
	"/assets/services-r49PEGRW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48cd2-Es6Jg2j9lKEUWtCskSIeP4MexJ8\"",
		"mtime": "2026-09-15T07:39:19.660Z",
		"size": 298194,
		"path": "../public/assets/services-r49PEGRW.js"
	},
	"/assets/styles-r49PEGRW.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1904f-Zfym/NWArktqtIucID2zgVwCQ58\"",
		"mtime": "2026-09-15T07:39:19.660Z",
		"size": 102479,
		"path": "../public/assets/styles-r49PEGRW.css"
	},
	"/og.png": {
		"type": "image/png",
		"etag": "\"1a740b-Te9dYaiwwQaN3MylyhTSv6Im15Q\"",
		"mtime": "2026-08-03T04:52:29.129Z",
		"size": 1733643,
		"path": "../public/og.png"
	},
	"/assets/hero-community-v2-5XDIHCKZ.png": {
		"type": "image/png",
		"etag": "\"1e6722-V2/10higtDF7j8T23fr7VIFv3Ik\"",
		"mtime": "2026-08-03T04:52:28.537Z",
		"size": 1992482,
		"path": "../public/assets/hero-community-v2-5XDIHCKZ.png"
	},
	"/assets/program-1-smart-house-B0a2nR0c.jpg": {
		"type": "image/jpeg",
		"etag": "\"2a5dc-N/8Wd79xcIeojeNIEON0HyMxfW4\"",
		"mtime": "2026-09-15T07:29:23.540Z",
		"size": 173532,
		"path": "../public/assets/program-1-smart-house-B0a2nR0c.jpg"
	},
	"/assets/program-2-health-center-HSYbmuFD.jpg": {
		"type": "image/jpeg",
		"etag": "\"4d5c7-rcnYD83R2p36dJm7bbgxzE8PYB0\"",
		"mtime": "2026-09-15T07:29:23.540Z",
		"size": 316871,
		"path": "../public/assets/program-2-health-center-HSYbmuFD.jpg"
	},
	"/assets/program-3-discharge-h6hfyEnB.jpg": {
		"type": "image/jpeg",
		"etag": "\"252df-FvEFbUmt5BsWIChDp3k4ycyV18o\"",
		"mtime": "2026-09-15T07:29:23.540Z",
		"size": 152287,
		"path": "../public/assets/program-3-discharge-h6hfyEnB.jpg"
	},
	"/assets/program-4-hospice-nPFnhrU5.jpg": {
		"type": "image/jpeg",
		"etag": "\"280ec-pAC4gfTbqc+qteOyc8sq2spNFZk\"",
		"mtime": "2026-09-15T07:29:23.540Z",
		"size": 164076,
		"path": "../public/assets/program-4-hospice-nPFnhrU5.jpg"
	},
	"/assets/program-5-exercise-y5VIsFLa.jpg": {
		"type": "image/jpeg",
		"etag": "\"29ed0-udLRHLBssrZbuGTFJfYG6Nt63yg\"",
		"mtime": "2026-09-15T07:29:23.540Z",
		"size": 171728,
		"path": "../public/assets/program-5-exercise-y5VIsFLa.jpg"
	},
	"/assets/program-6-home-visit-9TWm7bgZ.jpg": {
		"type": "image/jpeg",
		"etag": "\"2d1ea-NXQoUyse1gTlohd1ekiAG/y8i70\"",
		"mtime": "2026-09-15T07:29:23.540Z",
		"size": 184810,
		"path": "../public/assets/program-6-home-visit-9TWm7bgZ.jpg"
	},
	"/assets/program-7-medication-Qu6oEGQN.jpg": {
		"type": "image/jpeg",
		"etag": "\"2cbe8-FP+F4h6sdxPYTZzV1Ie1miMwlVc\"",
		"mtime": "2026-09-15T07:29:23.540Z",
		"size": 183272,
		"path": "../public/assets/program-7-medication-Qu6oEGQN.jpg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_N48TAc = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_N48TAc
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
