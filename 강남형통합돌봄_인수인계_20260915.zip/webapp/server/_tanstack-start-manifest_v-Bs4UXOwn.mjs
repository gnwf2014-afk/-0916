//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bs4UXOwn.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/build-site/src/routes/__root.tsx",
		children: ["/", "/services"],
		preloads: ["/assets/index-r49PEGRW.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-r49PEGRW.js"
		} }]
	},
	"/": {
		filePath: "/home/user/build-site/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-r49PEGRW.js", "/assets/map-gangnam-r49PEGRW.js"]
	},
	"/services": {
		filePath: "/home/user/build-site/src/routes/services.tsx",
		children: void 0,
		preloads: ["/assets/services-r49PEGRW.js", "/assets/map-gangnam-r49PEGRW.js"]
	}
} });
//#endregion
export { tsrStartManifest };
