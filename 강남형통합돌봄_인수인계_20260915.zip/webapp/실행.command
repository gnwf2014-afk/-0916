#!/bin/bash
# 강남형 통합돌봄 웹앱 실행 (macOS: 더블클릭)
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 가 설치되어 있지 않습니다. https://nodejs.org 에서 LTS 버전을 설치한 뒤 다시 실행하세요."
  read -n 1 -s -r -p "아무 키나 누르면 닫힙니다..."
  exit 1
fi
PORT="${PORT:-3000}"
( sleep 1.5; open "http://localhost:${PORT}" ) &
PORT="$PORT" node run.mjs
