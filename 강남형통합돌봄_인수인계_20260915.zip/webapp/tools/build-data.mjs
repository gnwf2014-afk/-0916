#!/usr/bin/env node
/**
 * 엑셀(사업대상기관 목록) → 웹앱 데이터 변환 스크립트
 *
 *   npm run data                         (상위 폴더에서 가장 최근 "…사업대상기관 목록*.xlsx" 자동 선택)
 *   npm run data -- "경로/파일.xlsx"      (파일 지정)
 *   npm run data -- --date 2026-09-11    (자료 기준일 지정, 기본: 파일명의 (MMDD) 또는 파일 수정일)
 *   npm run data -- --keep-duplicates    (중복 기관 병합하지 않음)
 *   npm run data -- --dry-run            (검증만 하고 파일은 쓰지 않음)
 *
 * 하는 일
 *  1. Sheet1 을 읽어 기관 데이터를 정제 (전화·주소·홈페이지 형식 통일, 주요대상 표준화, 중복 병합)
 *  2. server/_ssr/services-*.mjs (서버 렌더링용) 의 FACILITIES 배열과 기준일을 교체
 *  3. public/assets/services-*.js (브라우저용) 의 데이터 배열과 기준일을 교체
 *  4. 홈 화면의 "N개 참여기관" 통계 숫자를 서버·브라우저 양쪽에서 갱신
 *  5. 브라우저 캐시(1년 immutable) 때문에 JS 청크 파일명을 새 해시로 교체하고 모든 참조를 갱신
 *  6. client/assets 를 public/assets 와 동일하게 맞춤
 *  7. data/facilities.json 에 사람이 확인할 수 있는 결과를 기록
 */
import ExcelJS from "exceljs";
import { createHash } from "node:crypto";
import { existsSync, readdirSync, readFileSync, statSync, writeFileSync, unlinkSync, copyFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const args = process.argv.slice(2);
const flag = (name) => args.includes(name);
const opt = (name) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : undefined; };
const DRY = flag("--dry-run");
const KEEP_DUP = flag("--keep-duplicates");

// ───────────────────────── 입력 파일 찾기 ─────────────────────────
function findExcel() {
  const explicit = args.find((a) => a.toLowerCase().endsWith(".xlsx"));
  if (explicit) return path.resolve(explicit);
  const dirs = [path.resolve(ROOT, ".."), path.join(ROOT, "data"), ROOT];
  const found = [];
  for (const d of dirs) {
    if (!existsSync(d)) continue;
    for (const f of readdirSync(d)) {
      // macOS 는 파일명을 NFD(자모 분리) 로 돌려주므로 NFC 로 맞춰 비교
      if (/사업대상기관.*\.xlsx$/i.test(f.normalize("NFC")) && !f.startsWith("~$")) found.push(path.join(d, f));
    }
  }
  if (!found.length) fail("엑셀 파일을 찾을 수 없습니다. 상위 폴더에 \"…사업대상기관 목록….xlsx\" 를 두거나 경로를 인수로 주세요.");
  found.sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs);
  return found[0];
}
function fail(msg) { console.error("\n✖ " + msg + "\n"); process.exit(1); }

function inferDate(file) {
  if (opt("--date")) return opt("--date");
  const m = path.basename(file).match(/\((\d{2})(\d{2})\)/);
  const mtime = statSync(file).mtime;
  if (m) return `${mtime.getFullYear()}-${m[1]}-${m[2]}`;
  return mtime.toISOString().slice(0, 10);
}

// ───────────────────────── 정제 규칙 ─────────────────────────
const CATEGORY_COLUMNS = ["보건의료", "건강관리", "요양", "일상생활", "주거지원"];
const TAG_TO_CATEGORY = {
  "방문진료": "보건의료", "보건의료": "보건의료",
  "건강관리": "건강관리",
  "방문목욕": "요양", "장기요양보험": "요양", "요양": "요양",
  "일상돌봄": "일상생활", "신체돌봄": "일상생활", "긴급돌봄": "일상생활", "마음돌봄": "일상생활", "일상생활": "일상생활", "기타시범사업": "일상생활",
  "환경개선": "주거지원", "주택지원": "주거지원", "주거지원": "주거지원",
};

function text(v) {
  if (v == null) return "";
  if (typeof v === "object") {
    if (Array.isArray(v.richText)) v = v.richText.map((r) => r.text).join("");
    else if (v.text != null) v = v.text;
    else if (v.result != null) v = v.result;
    else v = String(v);
  }
  return String(v).replace(/\s+/g, " ").trim();
}

function cleanPhone(raw, warnings, name) {
  const s = text(raw);
  if (!s) return "";
  const digits = s.replace(/\D/g, "");
  let out;
  if (/^(15|16|18)\d{6}$/.test(digits)) out = digits.replace(/^(\d{4})(\d{4})$/, "$1-$2"); // 15xx-xxxx 전국 대표번호 (02 붙이면 안 됨)
  else if (/^02(15|16|18)\d{6}$/.test(digits)) out = digits.slice(2).replace(/^(\d{4})(\d{4})$/, "$1-$2"); // "02-1588-xxxx" 처럼 잘못 붙은 02 제거
  else if (/^02\d{7,8}$/.test(digits)) out = digits.replace(/^(02)(\d{3,4})(\d{4})$/, "$1-$2-$3");
  else if (/^\d{7,8}$/.test(digits)) out = ("02" + digits).replace(/^(02)(\d{3,4})(\d{4})$/, "$1-$2-$3"); // 지역번호 누락 → 서울(02)
  else if (/^010\d{8}$/.test(digits)) out = digits.replace(/^(010)(\d{4})(\d{4})$/, "$1-$2-$3");
  else if (/^0\d{11}$/.test(digits)) out = digits.replace(/^(\d{4})(\d{4})(\d{4})$/, "$1-$2-$3"); // 0507 안심번호 등
  else if (/^0\d{9,10}$/.test(digits)) out = digits.replace(/^(0\d{2})(\d{3,4})(\d{4})$/, "$1-$2-$3");
  else { warnings.push(`${name}: 전화번호 형식 확인 필요 "${s}"`); return s; }
  if (/^0207-/.test(out)) warnings.push(`${name}: 전화번호 "${out}" 는 0507(안심번호) 오타일 가능성이 있습니다`);
  return out;
}

function cleanAddress(raw) {
  let s = text(raw);
  if (!s) return { address: "", zip: "" };
  let zip = "";
  const m = s.match(/^\(\s*(\d{5})\s*\)\s*/);
  if (m) { zip = m[1]; s = s.slice(m[0].length); }
  s = s.replace(/[_\s]+$/g, "").replace(/\s+/g, " ").trim();
  s = s.replace(/^서울시\s+/, "서울특별시 ");
  if (/^강남구/.test(s)) s = "서울특별시 " + s;
  s = s.replace(/\s*,\s*/g, ", ");
  return { address: s, zip };
}

function cleanHomepage(raw) {
  let s = text(raw).replace(/\s/g, "");
  if (!s) return "";
  if (!/^https?:\/\//i.test(s)) s = "https://" + s;
  return s;
}

function normalizeTarget(raw) {
  const s = text(raw);
  if (!s) return { target: "", targetDetail: "" };
  const has = (k) => s.includes(k);
  let label;
  if (has("정신질환") || has("정신건강")) label = "정신건강 대상자";
  else if (has("재가암")) label = "재가암환자";
  else if (has("장애인") && has("노인")) label = "노인·장애인";
  else if (has("장애인")) label = "장애인";
  else if (has("노인") || has("어르신")) label = "노인";
  else if (has("주민") || has("직장인")) label = "지역주민";
  else label = s;
  return { target: label, targetDetail: label === s ? "" : s };
}

function splitTags(detail) {
  return text(detail).split(/[,/·]/).map((t) => t.trim()).filter((t) => t && t !== "미기재");
}

// ───────────────────────── 엑셀 읽기 ─────────────────────────
async function readExcel(file) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(file);
  const ws = wb.worksheets.find((w) => w.name === "Sheet1") || wb.worksheets[0];
  let headerRow = 0, headers = [];
  ws.eachRow((row, n) => {
    if (headerRow) return;
    const vals = Array.from(row.values, (v) => text(v)); // exceljs 는 빈 칸이 섞인 배열을 줌
    if (vals.includes("기관명")) { headerRow = n; headers = vals; }
  });
  if (!headerRow) fail("헤더 행(기관명 열)을 찾을 수 없습니다.");
  const col = (name) => {
    const i = headers.findIndex((h) => h && (h === name || h.startsWith(name)));
    if (i < 0) fail(`'${name}' 열이 없습니다. 헤더: ${headers.filter(Boolean).join(", ")}`);
    return i;
  };
  const C = {
    no: col("NO"), name: col("기관명"), target: col("주요대상"), phone: col("대표전화"), homepage: col("기관홈페이지"),
    address: col("주소"), detail: col("서비스유형"), content: col("주요내용"),
    cats: CATEGORY_COLUMNS.map((c) => col(c)),
  };
  const rows = [];
  ws.eachRow((row, n) => {
    if (n <= headerRow) return;
    const v = row.values;
    const name = text(v[C.name]);
    if (!name) return;
    rows.push({
      no: Number(text(v[C.no])) || rows.length + 1,
      name, target: v[C.target], phone: v[C.phone], homepage: v[C.homepage], address: v[C.address],
      detail: v[C.detail], content: v[C.content],
      cats: C.cats.map((ci) => Boolean(text(v[ci]))),
    });
  });
  return rows;
}

// ───────────────────────── 변환 ─────────────────────────
function transform(rows) {
  const warnings = [];
  const stats = { phoneFixed: 0, zipStripped: 0, homepageFixed: 0, targetNormalized: 0, servicesInferred: 0, merged: [] };
  let facilities = rows.map((r) => {
    const phoneRaw = text(r.phone);
    const phone = cleanPhone(r.phone, warnings, r.name);
    if (phone !== phoneRaw && phoneRaw) stats.phoneFixed++;
    const { address, zip } = cleanAddress(r.address);
    if (zip) stats.zipStripped++;
    const homepageRaw = text(r.homepage);
    const homepage = cleanHomepage(r.homepage);
    if (homepage !== homepageRaw && homepageRaw) stats.homepageFixed++;
    const { target, targetDetail } = normalizeTarget(r.target);
    if (targetDetail) stats.targetNormalized++;
    let services = CATEGORY_COLUMNS.filter((_, i) => r.cats[i]);
    const tags = splitTags(r.detail);
    if (!services.length && tags.length) {
      services = [...new Set(tags.map((t) => TAG_TO_CATEGORY[t]).filter(Boolean))];
      if (services.length) stats.servicesInferred++;
    }
    services.sort((a, b) => CATEGORY_COLUMNS.indexOf(a) - CATEGORY_COLUMNS.indexOf(b));
    if (!phone) warnings.push(`${r.name}: 대표전화 없음`);
    if (!address) warnings.push(`${r.name}: 주소 없음`);
    if (!services.length) warnings.push(`${r.name}: 서비스유형 미기재 (분류 없이 표시됨)`);
    return {
      no: r.no, name: r.name, target, targetDetail, phone, homepage, address, zip,
      services, detail: text(r.detail) || "미기재", content: text(r.content), tags,
    };
  });

  // 중복 기관 병합 (기관명 + 전화가 같으면 같은 기관으로 간주)
  if (!KEEP_DUP) {
    const byKey = new Map();
    const out = [];
    for (const f of facilities) {
      const key = `${f.name}|${f.phone}`;
      const prev = byKey.get(key);
      if (!prev) { byKey.set(key, f); out.push(f); continue; }
      stats.merged.push(`${f.name} (NO ${prev.no} + ${f.no})`);
      prev.services = CATEGORY_COLUMNS.filter((c) => prev.services.includes(c) || f.services.includes(c));
      prev.tags = [...new Set([...prev.tags, ...f.tags])];
      prev.detail = prev.tags.join(", ") || prev.detail;
      if (!prev.homepage) prev.homepage = f.homepage;
      if (!prev.address || (f.address && f.address.length > prev.address.length)) { prev.address = f.address || prev.address; prev.zip = prev.zip || f.zip; }
      if (f.target && f.target !== prev.target && !prev.target.includes(f.target)) prev.target = [prev.target, f.target].filter(Boolean).join("·");
      if (f.content && !prev.content.includes(f.content)) prev.content = [prev.content, f.content].filter(Boolean).join(" ");
    }
    facilities = out;
  }

  facilities.forEach((f, i) => { f.id = `G${String(i + 1).padStart(3, "0")}`; });
  return { facilities, warnings, stats };
}

// ───────────────────────── "주요 사업" 요약 추출 ─────────────────────────
// 현황조사 PDF에서 옮겨온 '주요내용' 원문은 목적·기간·장소 같은 세부 항목이 줄글로 뒤섞여 읽기 어렵다.
// 카드에는 핵심 사업만 3~4줄로 보여주기 위해 규칙 기반으로 항목을 추출하고,
// 규칙으로 잘 안 되는 기관은 data/highlights-overrides.json 에 기관명별로 직접 적어 덮어쓴다.
const META_KEYS = /^(목적|목표|기간|장소|운영\s*횟수|방법|이용\s*시간|본인\s*부담금?|비고|대상|담당|문의|참고|장비|운동기구|시간)\s*[:：]/;
const TAG_LABEL = {
  "방문목욕": "방문목욕 서비스 (요양보호사 가정 방문)",
  "장기요양보험": "장기요양보험 급여 서비스 (방문요양·주야간보호 등)",
  "방문진료": "방문진료",
  "보건의료": "보건의료 서비스",
  "건강관리": "건강관리 서비스",
  "일상돌봄": "일상생활 돌봄 지원",
  "신체돌봄": "신체활동·건강 돌봄",
  "마음돌봄": "정서 지원·마음 돌봄",
  "긴급돌봄": "긴급 돌봄 지원",
  "환경개선": "주거환경 개선 지원",
  "주택지원": "주거 지원",
  "주거지원": "주거 지원",
  "일상생활": "일상생활 지원",
  "요양": "요양 서비스",
  "기타시범사업": "기타 시범사업",
};
function cutText(s, max = 60) {
  s = s.trim();
  if (s.length <= max) return s;
  const cut = s.slice(0, max);
  const i = Math.max(cut.lastIndexOf(", "), cut.lastIndexOf(" "), cut.lastIndexOf("·"));
  return (i > max * 0.5 ? cut.slice(0, i) : cut).replace(/[,\s·(]+$/, "") + "…";
}
function cleanItem(s) {
  return String(s)
    .replace(/^[\s\-–—•·∙▪■□○◦※①-⑩]+/, "")
    .replace(/\s*(…|\.\.\.)\s*$/, "")
    .replace(/\s+v$/, "")
    .replace(/\s*-\s*\d+\s*-\s*$/, "") // PDF 페이지 번호 "- 18 -"
    .replace(/\s+/g, " ")
    .trim();
}
/** 괄호 안은 건드리지 않고 최상위에서만 구분자로 나눔 (예: "a(b, c), d" → ["a(b, c)", "d"]) */
function splitTopLevel(text, isSeparatorAt) {
  const parts = [];
  let depth = 0, start = 0;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === "(" || ch === "[" || ch === "「" || ch === "‘" || ch === "“") depth++;
    else if (ch === ")" || ch === "]" || ch === "」" || ch === "’" || ch === "”") depth = Math.max(0, depth - 1);
    else if (depth === 0) {
      const len = isSeparatorAt(text, i);
      if (len) { parts.push(text.slice(start, i)); start = i + len; i += len - 1; }
    }
  }
  parts.push(text.slice(start));
  return parts;
}
const sepComma = (t, i) => (t[i] === "," && t[i + 1] === " " && /[가-힣A-Za-z]/.test(t[i + 2] || "") ? 2 : 0);
const sepSentence = (t, i) => (/[.。]/.test(t[i]) && t[i + 1] === " " && /[가-힣A-Za-z※]/.test(t[i + 2] || "") ? 2 : 0);
const sepBullet = (t, i) => (/[∙•▪■·]/.test(t[i]) && (i === 0 || t[i - 1] === " ") && t[i + 1] === " " ? 2 : 0); // 가운뎃점은 양쪽 공백일 때만 항목 기호
const SKIP_ITEM = /^(※|\(?본인\s*부담금|구\s?분\b|일반\s*15%|기초생활수급|차상위|그\s*외\s*[:：]|수급자|참여기관 목록|현황조사 PDF)/;

/** 항목 뒤에 딸려 붙은 "∙ 기간 : …" 같은 세부 정보를 잘라냄 */
function stripTrailingMeta(s) {
  let out = s;
  const bullet = out.search(/\s[∙•▪■Ÿ]\s?/); // Ÿ 는 PDF 변환 시 깨진 글머리표
  if (bullet > 6) out = out.slice(0, bullet);
  const meta = out.search(/\s(목적|목표|기간|장소|운영\s*횟수|방법|이용\s*시간|본인\s*부담금?|비고|대상)\s*[:：]/);
  if (meta > 6) out = out.slice(0, meta);
  return out.trim();
}
/** 잘린 괄호 정리: 여는 괄호만 남으면 그 뒤를 지움 */
function balanceParens(s) {
  const open = (s.match(/\(/g) || []).length, close = (s.match(/\)/g) || []).length;
  if (open > close) { const i = s.lastIndexOf("("); if (i > 4) return s.slice(0, i).replace(/[\s,·]+$/, "") + (s.endsWith("…") ? "…" : ""); }
  return s;
}

// 정형화된 문구는 규칙으로 바로 요약 (의료기관 시범기관 안내문 등)
const PATTERN_RULES = [
  { test: /치과주치의 시범기관/, items: () => ["장애인 치과주치의 시범기관 (구강건강관리)", "중증장애인 대상 지속적·포괄적 구강건강 관리 제공"] },
  { test: /건강주치의 시범기관/, items: (t) => [
    "장애인 건강주치의 시범기관 (일반건강관리·장애관리 주치의)",
    /방문진료/.test(t) ? "방문진료 실시" : null,
    /재택의료센터/.test(t) ? "장기요양 재택의료센터 시범사업 방문 가능 기관" : null,
    "중증장애인 만성질환·장애 관련 건강관리를 지속적·포괄적으로 제공",
  ].filter(Boolean) },
  { test: /^전문요양보호 인력이 가정을 방문하여 목욕서비스/, items: () => ["요양보호사가 가정을 방문해 목욕 서비스와 개인위생 관리 지원", "방문 시 기본 신체 상태 확인 및 건강관리"] },
  { test: /^돌봄SOS\s*(일시재가|식사배달|주거편의|서비스제공기관)/, items: (t) => {
    const kind = t.match(/^돌봄SOS\s*(\S+)/)[1];
    const label = { "일시재가": "돌봄SOS 일시재가 서비스 (긴급·일시 돌봄이 필요한 분께 방문 돌봄)", "식사배달": "돌봄SOS 식사배달 서비스 (거동이 어려운 분께 식사 지원)", "주거편의": "돌봄SOS 주거편의 서비스 (간단한 수리·청소·방역 등 주거 지원)" }[kind];
    return label ? [label] : [];
  } },
];

function extractHighlights(content, tags, overrides) {
  if (overrides) return overrides.slice(0, 5);
  const text = (content || "").replace(/\s+/g, " ").trim();
  let items = [];
  const rule = PATTERN_RULES.find((r) => r.test.test(text));
  if (rule) items = rule.items(text);
  else if (text) {
    // 1) "∙ 목적 :" 같은 세부 항목이 시작되기 전의 머리말 요약 ("- a - b - c")
    const firstDetail = text.search(/\s[∙•·]\s*(목적|내용|대상|기간|장소|운영\s*횟수|방법|목표)\s*[:：]/);
    const head = firstDetail > 0 ? text.slice(0, firstDetail) : text;
    const dashItems = head.split(/(?:^|\s)[-–—•]\s+/).map(cleanItem).filter((s) => s.length >= 6);
    if (dashItems.length >= 2) items = dashItems;
    // 2) ①②③ 번호 항목
    if (!items.length && /[①-⑩]/.test(text)) items = text.split(/[①-⑩]/).map(cleanItem).filter((s) => s.length >= 6 && !META_KEYS.test(s));
    // 3) "∙ 내용 : ..." 세그먼트만 모음 (가운뎃점은 양쪽에 공백이 있을 때만 항목 기호로 봄)
    if (!items.length) {
      const segs = splitTopLevel(text, sepBullet).map((s) => s.trim()).filter(Boolean);
      const contents = segs.filter((s) => /^내용\s*[:：]/.test(s)).map((s) => cleanItem(s.replace(/^내용\s*[:：]\s*/, "")));
      if (contents.length) items = contents;
      else if (segs.length >= 2) items = segs.filter((s) => !META_KEYS.test(s)).map(cleanItem).filter((s) => s.length >= 6);
    }
    // 4) 줄글 한 덩어리면 문장, 그다음 쉼표로 나눔 (괄호 안은 유지)
    if (items.length <= 1 && text.length > 40) {
      let parts = splitTopLevel(text, sepSentence).map(cleanItem).filter((s) => s.length >= 6);
      if (parts.length < 2) parts = splitTopLevel(text, sepComma).map(cleanItem).filter((s) => s.length >= 6);
      if (parts.length >= 2) items = parts;
    }
    if (!items.length) items = [cleanItem(text)];
  }
  const seen = new Set();
  const out = [];
  for (let it of items) {
    it = stripTrailingMeta(cleanItem(it).replace(/^내용\s*[:：]\s*/, ""));
    if (!it || META_KEYS.test(it) || SKIP_ITEM.test(it)) continue;
    it = balanceParens(cutText(it, 64));
    const key = it.replace(/[^가-힣A-Za-z0-9]/g, "");
    if (key.length < 4 || seen.has(key)) continue;
    seen.add(key);
    out.push(it);
    if (out.length >= 4) break;
  }
  // 항목이 1개 이하면 서비스유형 태그로 보충 (이미 언급된 유형은 제외)
  if (out.length < 2 && tags?.length) {
    const joined = out.join(" ");
    for (const t of tags) {
      const label = TAG_LABEL[t];
      if (label && !joined.includes(t) && !out.includes(label)) out.push(label);
      if (out.length >= 3) break;
    }
  }
  return out;
}
const OVERRIDES_FILE = path.join(ROOT, "data", "highlights-overrides.json");
const HIGHLIGHT_OVERRIDES = existsSync(OVERRIDES_FILE) ? JSON.parse(readFileSync(OVERRIDES_FILE, "utf8")) : {};

// 앱 데이터 스키마 (기존 필드 유지 + 확장 필드 추가)
const toRecord = (f) => ({
  id: f.id, name: f.name, target: f.target, phone: f.phone, homepage: f.homepage, address: f.address,
  services: f.services, detail: f.detail, content: f.content,
  highlights: extractHighlights(f.content, f.tags, HIGHLIGHT_OVERRIDES[f.name]),
  targetDetail: f.targetDetail, zip: f.zip, tags: f.tags,
});

// ───────────────────────── 파일 패치 유틸 ─────────────────────────
/** 배열 리터럴 시작 인덱스에서 문자열을 고려해 닫는 대괄호 인덱스를 찾음 */
function findArrayEnd(src, start) {
  let depth = 0, quote = null;
  for (let i = start; i < src.length; i++) {
    const ch = src[i];
    if (quote) {
      if (ch === "\\") { i++; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === "\"" || ch === "'" || ch === "`") { quote = ch; continue; }
    if (ch === "[" || ch === "{") depth++;
    else if (ch === "]" || ch === "}") { depth--; if (depth === 0) return i; }
  }
  fail("배열 끝을 찾지 못했습니다.");
}
const asciiJson = (v) => JSON.stringify(v).replace(/[-￿]/g, (c) => "\\u" + c.charCodeAt(0).toString(16).toUpperCase().padStart(4, "0"));
const etagOf = (buf) => `"${buf.length.toString(16)}-${createHash("sha1").update(buf).digest("base64").slice(0, 27)}"`;
function one(dir, re) {
  const list = readdirSync(dir).filter((f) => re.test(f));
  if (list.length !== 1) fail(`${dir} 에서 ${re} 파일이 ${list.length}개입니다 (1개여야 함).`);
  return list[0];
}
const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function patchServerData(src, records, date) {
  const start = src.indexOf("var FACILITIES = [");
  if (start < 0) fail("서버 파일에서 FACILITIES 배열을 찾을 수 없습니다.");
  const arrStart = src.indexOf("[", start);
  const arrEnd = findArrayEnd(src, arrStart);
  src = src.slice(0, arrStart) + JSON.stringify(records, null, "\t") + src.slice(arrEnd + 1);
  if (!/var FACILITY_SOURCE_DATE = "[^"]*"/.test(src)) fail("서버 파일에서 FACILITY_SOURCE_DATE 를 찾을 수 없습니다.");
  return src.replace(/var FACILITY_SOURCE_DATE = "[^"]*"/, `var FACILITY_SOURCE_DATE = "${date}"`);
}

function patchClientData(src, records, date) {
  // 원본 번들은 {id:"G001",name:…}, 이 스크립트가 쓴 결과물은 {"id":"G001","name":…} 형식이므로 둘 다 인식
  const m = src.match(/\[\{"?id"?:"G\d{3}","?name"?:"/);
  if (!m) fail("브라우저 번들에서 데이터 배열 시작을 찾을 수 없습니다.");
  const arrStart = m.index;
  const arrEnd = findArrayEnd(src, arrStart);
  const after = src.slice(arrEnd + 1);
  const dm = after.match(/^,([A-Za-z_$][\w$]*)="\d{4}-\d{2}-\d{2}"/);
  if (!dm) fail("브라우저 번들에서 기준일 상수를 찾을 수 없습니다.");
  return src.slice(0, arrStart) + asciiJson(records) + `,${dm[1]}="${date}"` + after.slice(dm[0].length);
}

/** '참여기관' 라벨 바로 앞에 있는 "N개" 숫자를 교체 */
function patchHomeStat(src, count, label) {
  const idx = src.indexOf(label);
  if (idx < 0) return { src, changed: false, found: false };
  const head = src.slice(0, idx);
  const re = /children:\s*(["`])(\d+)개\1/g;
  let last = null, m;
  while ((m = re.exec(head))) last = m;
  if (!last) return { src, changed: false, found: false };
  const replaced = `children:${last[0].slice("children:".length).replace(last[2], String(count))}`;
  const patched = head.slice(0, last.index) + replaced + head.slice(last.index + last[0].length);
  return { src: patched + src.slice(idx), changed: last[2] !== String(count), found: true };
}

// ───────────────────────── 메인 ─────────────────────────
const excel = findExcel();
const date = inferDate(excel);
console.log(`\n▶ 입력: ${excel}\n▶ 자료 기준일: ${date}${DRY ? "   (dry-run: 파일 변경 없음)" : ""}\n`);

const rows = await readExcel(excel);
const { facilities, warnings, stats } = transform(rows);
const records = facilities.map(toRecord);

console.log(`엑셀 행 ${rows.length}개 → 기관 ${records.length}개`);
console.log(`  전화 형식 통일 ${stats.phoneFixed}건 · 우편번호 분리 ${stats.zipStripped}건 · 홈페이지 주소 보정 ${stats.homepageFixed}건`);
console.log(`  주요대상 표준화 ${stats.targetNormalized}건 · 서비스유형 추론 ${stats.servicesInferred}건 · 중복 병합 ${stats.merged.length}건${stats.merged.length ? " (" + stats.merged.join(", ") + ")" : ""}`);
const byCat = CATEGORY_COLUMNS.map((c) => `${c} ${records.filter((r) => r.services.includes(c)).length}`).join(" · ");
console.log(`  분류별: ${byCat}`);
if (warnings.length) { console.log(`\n⚠ 확인 필요 ${warnings.length}건`); warnings.forEach((w) => console.log("   - " + w)); }

// 파일 위치 (파일명 해시는 매번 달라질 수 있어 패턴으로 찾음)
const PUB = path.join(ROOT, "public", "assets");
const CLI = path.join(ROOT, "client", "assets");
const SSR = path.join(ROOT, "server", "_ssr");
const serverDataFile = path.join(SSR, one(SSR, /^services-.*\.mjs$/));
const serverRoutesFile = path.join(SSR, one(SSR, /^routes-.*\.mjs$/));
const manifestFile = path.join(ROOT, "server", one(path.join(ROOT, "server"), /^_tanstack-start-manifest.*\.mjs$/));
const chunkNames = {
  index: one(PUB, /^index-.*\.js$/),
  routes: one(PUB, /^routes-.*\.js$/),
  services: one(PUB, /^services-.*\.js$/),
  "map-gangnam": one(PUB, /^map-gangnam-.*\.js$/),
  styles: one(PUB, /^styles-.*\.css$/), // 스타일시트도 패치 대상이라 함께 이름을 바꿈
};
const MIME_BY_EXT = { ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8" };

// 1) 서버 데이터
const serverData = patchServerData(readFileSync(serverDataFile, "utf8"), records, date);
// 2) 브라우저 데이터
const chunks = Object.fromEntries(Object.entries(chunkNames).map(([k, f]) => [k, readFileSync(path.join(PUB, f), "utf8")]));
chunks.services = patchClientData(chunks.services, records, date);
// 3) 홈 통계
let serverRoutes = readFileSync(serverRoutesFile, "utf8");
const s1 = patchHomeStat(serverRoutes, records.length, "children: \"참여기관\""); serverRoutes = s1.src;
const s2 = patchHomeStat(chunks.routes, records.length, "children:`참여기관`"); chunks.routes = s2.src;
const stateOf = (s) => (!s.found ? "위치 못 찾음" : s.changed ? "갱신" : "변경 없음");
console.log(`\n홈 화면 참여기관 수 → ${records.length}개 (서버 ${stateOf(s1)}, 브라우저 ${stateOf(s2)})`);

// 4) 청크 파일명 갱신 (1년 immutable 캐시 무효화).
//    데이터·기준일·청크 코드가 모두 같으면 같은 이름이 나오므로 재실행해도 안전하고, 코드가 바뀌면 이름도 바뀜
const stripNames = (s) => Object.entries(chunkNames).reduce((acc, [k, f]) => acc.split(f).join(`${k}-HASH${path.extname(f)}`), s);
const tokenSource = JSON.stringify(records) + date + Object.keys(chunks).sort().map((k) => stripNames(chunks[k])).join("\n");
const token = createHash("sha256").update(tokenSource).digest("base64url").replace(/[^A-Za-z0-9]/g, "").slice(0, 8);
const rename = Object.fromEntries(Object.entries(chunkNames).map(([k, old]) => [old, `${k}-${token}${path.extname(old)}`]));
const applyRename = (s) => Object.entries(rename).reduce((acc, [o, n]) => acc.split(o).join(n), s);
for (const k of Object.keys(chunks)) chunks[k] = applyRename(chunks[k]);
const manifest = applyRename(readFileSync(manifestFile, "utf8"));
// 서버 렌더링 코드(_ssr/*.mjs)도 청크 이름을 참조함 (예: router 의 스타일시트 경로)
const ssrTargets = readdirSync(SSR).filter((f) => f.endsWith(".mjs")).map((f) => path.join(SSR, f));
const ssrPatched = ssrTargets.map((f) => {
  const before = f === serverDataFile ? serverData : f === serverRoutesFile ? serverRoutes : readFileSync(f, "utf8");
  return [f, applyRename(before), before];
});
const newFiles = Object.fromEntries(Object.entries(chunkNames).map(([k, old]) => [rename[old], Buffer.from(chunks[k], "utf8")]));

// 5) server/index.mjs, index.js 의 정적 자산 테이블 (경로·etag·크기)
function patchAssetTable(src) {
  for (const [old, neu] of Object.entries(rename)) {
    const re = new RegExp(`"/assets/${escapeRe(old)}": \\{[^}]*\\}`);
    if (!re.test(src)) fail(`자산 테이블에서 ${old} 항목을 찾을 수 없습니다.`);
    const buf = newFiles[neu];
    const entry = [
      `"/assets/${neu}": {`,
      `\t\t"type": "${MIME_BY_EXT[path.extname(neu)] || "application/octet-stream"}",`,
      `\t\t"etag": ${JSON.stringify(etagOf(buf))},`,
      `\t\t"mtime": "${new Date().toISOString()}",`,
      `\t\t"size": ${buf.length},`,
      `\t\t"path": "../public/assets/${neu}"`,
      `\t}`,
    ].join("\n");
    src = src.replace(re, entry);
  }
  return src;
}
const indexTargets = ["index.mjs", "index.js"].map((f) => path.join(ROOT, "server", f)).filter(existsSync);
const indexPatched = indexTargets.map((f) => [f, patchAssetTable(readFileSync(f, "utf8"))]);

const renamedCount = Object.entries(rename).filter(([o, n]) => o !== n).length;
console.log(`브라우저 청크 파일명 ${renamedCount ? "갱신" : "변경 없음"}: ${Object.values(rename).join(", ")}`);

if (DRY) { console.log("\n(dry-run) 검증 완료. 파일은 변경하지 않았습니다.\n"); process.exit(0); }

// 6) 쓰기
mkdirSync(path.join(ROOT, "data"), { recursive: true });
writeFileSync(path.join(ROOT, "data", "facilities.json"), JSON.stringify({
  sourceFile: path.basename(excel), sourceDate: date, count: records.length,
  generatedAt: new Date().toISOString(), warnings, facilities: records,
}, null, 2) + "\n");
for (const [f, after, before] of ssrPatched) if (after !== before || f === serverDataFile || f === serverRoutesFile) writeFileSync(f, after);
writeFileSync(manifestFile, manifest);
for (const [f, s] of indexPatched) writeFileSync(f, s);
for (const dir of [PUB, CLI]) {
  mkdirSync(dir, { recursive: true });
  for (const [old, neu] of Object.entries(rename)) {
    writeFileSync(path.join(dir, neu), newFiles[neu]);
    if (old !== neu && existsSync(path.join(dir, old))) unlinkSync(path.join(dir, old));
  }
}
// client/assets 에 없는 정적 파일은 public/assets 에서 복사
for (const f of readdirSync(PUB)) if (!existsSync(path.join(CLI, f))) copyFileSync(path.join(PUB, f), path.join(CLI, f));

console.log("\n✔ 완료. 결과 확인: data/facilities.json\n  실행 중인 서버가 있으면 다시 시작해야 반영됩니다 (npm start).\n");
