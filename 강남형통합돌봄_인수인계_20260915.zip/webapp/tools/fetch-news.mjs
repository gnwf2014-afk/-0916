#!/usr/bin/env node
/**
 * 정보나눔 — 보건복지부 보도자료 수집 스크립트
 *
 *   node tools/fetch-news.mjs              RSS(최신 30건)에서 키워드에 맞는 글을 골라 public/news.json 에 누적
 *   node tools/fetch-news.mjs --seed       처음 한 번: 게시판 제목검색으로 과거 글까지 모아 초기 목록을 채움
 *   node tools/fetch-news.mjs --pages 5    (--seed 와 함께) 키워드별로 읽을 검색 페이지 수 (기본 7, 페이지당 15건)
 *   node tools/fetch-news.mjs --dry-run    파일을 쓰지 않고 결과만 출력
 *
 * 출처: 보건복지부 보도자료 (https://www.mohw.go.kr/board.es?mid=a10503010100&bid=0027)
 *       공식 RSS: https://www.mohw.go.kr/rss/board.es?mid=a10503000000&bid=0027&info
 * 저작권: 공공누리 출처표시 조건 — 제목·날짜·짧은 요약과 원문 링크만 게재하고 출처를 표시한다.
 *
 * run.mjs 가 이 파일의 updateNews() 를 하루 한 번 호출한다. 외부 라이브러리 없이 Node 내장 기능만 사용.
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const OUT_FILES = [path.join(ROOT, "public", "news.json"), path.join(ROOT, "client", "news.json")];
const KEYWORDS_FILE = path.join(ROOT, "data", "news-keywords.json");

const SOURCE = {
  name: "보건복지부 보도자료",
  url: "https://www.mohw.go.kr/board.es?mid=a10503010100&bid=0027",
  rss: "https://www.mohw.go.kr/rss/board.es?mid=a10503000000&bid=0027&info",
  license: "공공누리 제1유형(출처표시)",
};
const LIST_URL = (kw, page) => `https://www.mohw.go.kr/board.es?mid=a10503010100&bid=0027&keyField=TITLE&keyWord=${encodeURIComponent(kw)}&nPage=${page}`;
const VIEW_URL = (no) => `https://www.mohw.go.kr/board.es?mid=a10503010100&bid=0027&act=view&list_no=${no}`;
const UA = "Mozilla/5.0 (compatible; GangnamCareNewsBot/1.0; +https://github.com/gangnam-care)";

// ───────── 유틸 ─────────
async function get(url, timeoutMs = 20000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const res = await fetch(url, { headers: { "user-agent": UA, accept: "text/html,application/xml,text/xml;q=0.9,*/*;q=0.8" }, signal: ac.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} ${url}`);
    return await res.text();
  } finally { clearTimeout(t); }
}
const ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ", lsquo: "‘", rsquo: "’", ldquo: "“", rdquo: "”", middot: "·", hellip: "…", ndash: "–", mdash: "—", times: "×" };
function decode(s) {
  return String(s || "")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<[^>]+>/g, " ")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&([a-z]+);/gi, (m, k) => ENTITIES[k.toLowerCase()] ?? m)
    .replace(/[？]/g, " ") // 복지부 RSS 에 섞여 나오는 깨진 문자
    .replace(/\s+/g, " ")
    .trim();
}
const norm = (s) => String(s || "").replace(/\s+/g, "").toLowerCase();
const listNoOf = (link) => (String(link).match(/list_no=(\d+)/) || [])[1] || null;
function toKstDate(pubDate) {
  const d = new Date(pubDate);
  if (Number.isNaN(d.getTime())) return "";
  return new Date(d.getTime() + 9 * 3600 * 1000).toISOString().slice(0, 10);
}
function summarize(text, max = 220) {
  let s = decode(text);
  // 제목·부제("- ... -") 반복 부분을 지우고 본문 첫 문장부터
  const body = s.indexOf("보건복지부(");
  if (body > 40) s = s.slice(body);
  s = s.replace(/^(\s*-\s*[^-]{4,80}-\s*)+/, "").trim();
  if (s.length <= max) return s;
  const cut = s.slice(0, max);
  const i = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf(", "), cut.lastIndexOf(" "));
  return (i > max * 0.6 ? cut.slice(0, i) : cut).replace(/[,\s]+$/, "") + "…";
}

// ───────── 파싱 ─────────
function parseRss(xml) {
  const items = [];
  for (const m of xml.matchAll(/<item>([\s\S]*?)<\/item>/g)) {
    const block = m[1];
    const field = (tag) => (block.match(new RegExp(`<${tag}>([\\s\\S]*?)<\\/${tag}>`)) || [])[1] || "";
    const link = decode(field("link"));
    const id = listNoOf(link);
    if (!id) continue;
    items.push({
      id, title: decode(field("title")), link: VIEW_URL(id),
      date: toKstDate(decode(field("pubDate"))), dept: "", summary: summarize(field("description")), raw: decode(field("description")),
    });
  }
  return items;
}
function parseList(html) {
  const items = [];
  for (const m of html.matchAll(/<tr>([\s\S]*?)<\/tr>/g)) {
    const row = m[1];
    const a = row.match(/<a href="([^"]*list_no=(\d+)[^"]*)"[^>]*class="txt_title"[^>]*>([\s\S]*?)<\/a>/);
    if (!a) continue;
    const dept = (row.match(/data-label="담당부서">([\s\S]*?)<\/td>/) || [])[1] || "";
    const date = (row.match(/data-label="등록일">\s*(\d{4}-\d{2}-\d{2})/) || [])[1] || "";
    items.push({ id: a[2], title: decode(a[3]), link: VIEW_URL(a[2]), date, dept: decode(dept), summary: "", raw: "" });
  }
  return { items, total: Number((html.match(/전체\s*<b>(\d+)건/) || [])[1] || 0) };
}
/** 상세 페이지 본문(<article class="board_view">)에서 첫 문단을 요약으로 뽑음 */
function parseDetailSummary(html) {
  const m = html.match(/<article[^>]*class="[^"]*board_view[^"]*"[^>]*>([\s\S]*?)<\/article>/i);
  if (!m) return "";
  let text = decode(m[1].replace(/<(script|style)[\s\S]*?<\/\1>/gi, " "));
  // 본문 시작: "보건복지부(장관 …)는" 이 처음 나오는 곳부터, 없으면 첫 □ 항목부터
  const start = text.search(/보건복지부\([^)]*\)[은는이가]/);
  if (start > 0) text = text.slice(start);
  else { const box = text.indexOf("□ "); if (box > 0) text = text.slice(box + 2); }
  text = text.replace(/\s*<\s*붙임\s*>[\s\S]*$/, "").replace(/첨부파일[\s\S]*$/, "").trim();
  return text.length > 30 ? summarize(text) : "";
}

// ───────── 키워드 ─────────
function loadKeywords() {
  const k = existsSync(KEYWORDS_FILE) ? JSON.parse(readFileSync(KEYWORDS_FILE, "utf8")) : {};
  return {
    include: (k.include || ["통합돌봄"]).filter((s) => !s.startsWith("_")),
    core: (k.core || ["통합돌봄", "돌봄통합", "재택의료", "방문진료"]).filter((s) => !s.startsWith("_")),
    exclude: k.exclude || [],
    excludeIds: (k.excludeIds || []).map(String),
    since: k.since || "",
  };
}
/**
 * 관련도 판정
 *  2 = 핵심: 제목에 키워드가 있음
 *  1 = 관련: 본문(요약)에 핵심 키워드(core)가 있음
 *  0 = 제외: 본문에 일반 키워드만 스치듯 나옴 (예: 예산안에 '장기요양' 한 번)
 */
function matchTags(item, kws) {
  if (kws.since && item.date && item.date < kws.since) return { tags: [], relevance: 0 };
  if (kws.excludeIds.includes(String(item.id))) return { tags: [], relevance: 0 };
  const title = norm(item.title), body = norm(item.raw || item.summary || "");
  if (kws.exclude.some((x) => (title + body).includes(norm(x)))) return { tags: [], relevance: 0 };
  const inTitle = kws.include.filter((k) => title.includes(norm(k)));
  if (inTitle.length) return { tags: inTitle, relevance: 2 };
  const inBody = kws.core.filter((k) => body.includes(norm(k)));
  if (inBody.length) return { tags: inBody, relevance: 1 };
  return { tags: [], relevance: 0 };
}
const cleanTitle = (t) => String(t || "").replace(/^\s*(새글|NEW|new)\s*/i, "").trim();
/** 요약 첫머리의 "보건복지부(장관 ○○○)는 " 을 떼어 본문 요지부터 보이게 함 */
const trimLead = (s) => String(s || "").replace(/^보건복지부\([^)]*\)(?:[은는이가와과]|,)?\s*/, "").replace(/^\s*/, "");

// ───────── 메인 ─────────
export async function updateNews({ seed = false, pages = 7, dryRun = false, detailLimit = 15, log = console.log } = {}) {
  const kws = loadKeywords();
  const existing = existsSync(OUT_FILES[0]) ? JSON.parse(readFileSync(OUT_FILES[0], "utf8")) : { items: [] };
  // 기존 목록도 현재 기준(since)으로 정리해 너무 오래된 글은 제외
  const byId = new Map((existing.items || []).filter((it) => !kws.since || !it.date || it.date >= kws.since).map((it) => [it.id, it]));
  const before = byId.size;
  let fetched = 0, matched = 0;

  // 1) RSS
  const rssItems = parseRss(await get(SOURCE.rss));
  fetched += rssItems.length;
  for (const it of rssItems) {
    it.title = cleanTitle(it.title);
    const { tags, relevance } = matchTags(it, kws);
    if (!relevance) continue;
    matched++;
    const prev = byId.get(it.id) || {};
    byId.set(it.id, { ...prev, ...it, dept: it.dept || prev.dept || "", summary: it.summary || prev.summary || "", tags, relevance });
  }

  // 2) 초기 적재: 키워드 제목검색 (RSS 는 최신 30건만 주므로 과거 글을 모으는 용도)
  if (seed) {
    for (const kw of kws.include) {
      // 검색은 짧은 핵심 키워드만 (긴 문구는 결과가 거의 없음)
      if (kw.length > 6) continue;
      for (let p = 1; p <= pages; p++) {
        let parsed;
        try { parsed = parseList(await get(LIST_URL(kw, p))); } catch (e) { log(`  ! 검색 실패 (${kw} p${p}): ${e.message}`); break; }
        fetched += parsed.items.length;
        for (const it of parsed.items) {
          it.title = cleanTitle(it.title);
          const { tags, relevance } = matchTags(it, kws);
          if (!relevance) continue;
          matched++;
          const prev = byId.get(it.id) || {};
          byId.set(it.id, { ...prev, ...it, summary: prev.summary || "", tags: prev.tags?.length ? prev.tags : tags, relevance: Math.max(relevance, prev.relevance || 0) });
        }
        if (!parsed.items.length || p * 15 >= parsed.total) break;
        await new Promise((r) => setTimeout(r, 400)); // 예의상 간격
      }
    }
  }

  // 3) 요약이 없는 글은 상세 페이지의 메타 설명으로 보완 (하루 최대 detailLimit 건)
  const needSummary = [...byId.values()].filter((it) => !it.summary && !it.noSummary).sort((a, b) => (b.date || "").localeCompare(a.date || "")).slice(0, detailLimit);
  for (const it of needSummary) {
    try {
      const s = parseDetailSummary(await get(it.link));
      if (s) it.summary = s; else it.noSummary = true;
    } catch { /* 다음 실행에서 재시도 */ }
    await new Promise((r) => setTimeout(r, 300));
  }

  // 기존 항목도 현재 기준으로 관련도·태그를 다시 계산하고, 제외 대상은 뺌
  const items = [...byId.values()]
    .map((it) => {
      it.title = cleanTitle(it.title);
      const { tags, relevance } = matchTags({ ...it, raw: it.raw || it.summary }, kws);
      return { ...it, tags, relevance };
    })
    .filter((it) => it.relevance > 0)
    .map(({ raw, noSummary, ...it }) => ({ ...it, summary: trimLead(it.summary) }))
    .sort((a, b) => (b.date || "").localeCompare(a.date || "") || Number(b.id) - Number(a.id));
  const out = { source: SOURCE, keywords: kws.include, coreKeywords: kws.core, updatedAt: new Date().toISOString(), count: items.length, items };

  log(`보도자료 ${fetched}건 확인 → 키워드 일치 ${matched}건, 누적 ${before} → ${items.length}건 (신규 ${items.length - before}건)`);
  if (!dryRun) {
    for (const f of OUT_FILES) {
      if (!existsSync(path.dirname(f))) continue;
      mkdirSync(path.dirname(f), { recursive: true });
      writeFileSync(f, JSON.stringify(out, null, 2) + "\n");
    }
    log(`✔ 저장: ${OUT_FILES.filter((f) => existsSync(f)).map((f) => path.relative(ROOT, f)).join(", ")}`);
  }
  return out;
}

// CLI 로 직접 실행된 경우
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : undefined; };
  updateNews({ seed: args.includes("--seed"), pages: Number(opt("--pages")) || 7, dryRun: args.includes("--dry-run"), detailLimit: Number(opt("--details")) || (args.includes("--seed") ? 40 : 15) })
    .then((out) => { if (args.includes("--dry-run")) console.log(out.items.slice(0, 5)); })
    .catch((e) => { console.error("✖ 수집 실패:", e.message); process.exit(1); });
}
