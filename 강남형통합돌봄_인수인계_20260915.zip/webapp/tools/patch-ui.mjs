#!/usr/bin/env node
/**
 * 화면(UI) 패치 스크립트 — 원본 소스가 없어 빌드 결과물(서버 SSR 코드 + 브라우저 번들 + 스타일시트)을 직접 고친다.
 * 모든 패치는 이미 적용돼 있으면 건너뛰므로 여러 번 실행해도 안전하다.
 *
 *   node tools/patch-ui.mjs          적용
 *   node tools/patch-ui.mjs --check  적용 여부만 확인
 *
 * 패치 목록
 *  [기관 카드]  기관 홈페이지 링크 · "주요 사업" 목록 · 전화번호 tel 링크 · "자세히" 상세 팝업
 *  [기관 목록]  이용대상 필터 · 상황 필터(URL tags) · URL 파라미터(q/category/target/tags) · 검색 범위 확대 · 자료 기준일·수정 요청 안내
 *  [홈]         상황 카드 → 필터 연결 · 정보나눔 섹션(v2) · "소식·문의" → "상담·문의"
 *  [헤더]       "정보나눔" 메뉴 · 어두운 모드 / 글자 크게 버튼 + 초기화 스크립트
 *  [스타일]     어두운 모드 팔레트 · 명도 대비 보정 · 어절 단위 줄바꿈 · 글자 크게 모드 · 팝업/버튼 스타일
 *
 * 패치 후에는 반드시 `npm run data` 를 실행해 파일명(캐시 해시)과 etag 를 갱신할 것.
 */
import { existsSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CHECK = process.argv.includes("--check");
const one = (dir, re) => {
  const list = readdirSync(dir).filter((f) => re.test(f));
  if (list.length !== 1) throw new Error(`${dir} 에서 ${re} 파일이 ${list.length}개입니다.`);
  return path.join(dir, list[0]);
};
const PUB = path.join(ROOT, "public", "assets");
const SSR = path.join(ROOT, "server", "_ssr");
const FILES = {
  serverServices: one(SSR, /^services-.*\.mjs$/),
  serverRoutes: one(SSR, /^routes-.*\.mjs$/),
  serverMap: one(SSR, /^map-gangnam-.*\.mjs$/),
  clientServices: one(PUB, /^services-.*\.js$/),
  clientRoutes: one(PUB, /^routes-.*\.js$/),
  clientMap: one(PUB, /^map-gangnam-.*\.js$/),
  styles: one(PUB, /^styles-.*\.css$/),
};
const src = Object.fromEntries(Object.entries(FILES).map(([k, f]) => [k, readFileSync(f, "utf8")]));
const changed = new Set();
const results = [];
const KO = (s) => s.replace(/[-￿]/g, (c) => "\\u" + c.charCodeAt(0).toString(16).toUpperCase().padStart(4, "0"));
const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function apply(name, fileKey, isApplied, transform) {
  if (isApplied(src[fileKey])) { results.push(`  = ${name}: 이미 적용됨`); return; }
  if (CHECK) { results.push(`  ! ${name}: 미적용`); return; }
  const out = transform(src[fileKey]);
  if (out === src[fileKey] || out == null) throw new Error(`${name}: 패치 지점을 찾지 못했습니다 (${path.basename(FILES[fileKey])}). 번들 구조가 달라진 것 같습니다.`);
  src[fileKey] = out;
  changed.add(fileKey);
  results.push(`  + ${name}: 적용`);
}
const count = (s, from) => (typeof from === "string" ? s.split(from).length - 1 : (s.match(new RegExp(from.source, "g")) || []).length);
const replaceOnce = (s, from, to) => (count(s, from) !== 1 ? s : s.replace(from, () => to));
const insertBefore = (s, anchor, insertion) => (count(s, anchor) !== 1 ? s : s.replace(anchor, (m) => insertion + m));
const insertAfter = (s, anchor, insertion) => (count(s, anchor) !== 1 ? s : s.replace(anchor, (m) => m + insertion));
const must = (s, before, label) => { if (s === before) throw new Error(label + ": 지점을 찾지 못했습니다"); return s; };

/** 파일 끝에 붙이는 코드 블록: 이름으로 교체 가능 (버전 갱신용) */
function upsertBlock(s, name, code) {
  const begin = `\n//#gc-begin:${name}\n`, end = `\n//#gc-end:${name}\n`;
  const re = new RegExp(escapeRe(begin) + "[\\s\\S]*?" + escapeRe(end));
  const block = begin + code.trim() + end;
  return re.test(s) ? s.replace(re, () => block) : s + block;
}
/** 공용 컴포넌트 템플릿 → 서버/브라우저 코드로 변환 */
const toServer = (t) => t.replace(/JSXS\(/g, "(0, import_jsx_runtime.jsxs)(").replace(/JSX\(/g, "(0, import_jsx_runtime.jsx)(").replace(/REACT\./g, "import_react.");
const toClient = (t, jsx, react) => t.replace(/JSXS\(/g, `(0,${jsx}.jsxs)(`).replace(/JSX\(/g, `(0,${jsx}.jsx)(`).replace(/REACT\./g, `${react}.`);

// ═════════════════════════════ 1. 기관 홈페이지 링크 (브라우저) ═════════════════════════════
const HOMEPAGE_LABEL = KO("기관 홈페이지 ");
apply("기관 홈페이지 링크 (브라우저)", "clientServices", (s) => s.includes(HOMEPAGE_LABEL), (s) => {
  const oldFooter =
    '(0,e.jsxs)("a",{href:`https://map.naver.com/p/search/${encodeURIComponent(a.address)}`,target:"_blank",rel:"noreferrer",' +
    'className:"mt-auto flex items-center justify-between border-t border-[#edf2f1] pt-4 text-xs font-black text-[#07877f]",' +
    'children:["\\uC9C0\\uB3C4\\uC5D0\\uC11C \\uBCF4\\uAE30 ",(0,e.jsx)(T,{className:"h-4 w-4"})]})';
  const newFooter =
    '(0,e.jsxs)("div",{className:"mt-auto flex items-center justify-between gap-3 border-t border-[#edf2f1] pt-4 text-xs font-black",children:[' +
    'a.homepage?(0,e.jsxs)("a",{href:a.homepage.startsWith("http")?a.homepage:`https://${a.homepage}`,target:"_blank",rel:"noreferrer",' +
    'className:"flex items-center gap-1 truncate text-[#07877f]",children:["' + HOMEPAGE_LABEL + '",(0,e.jsx)(T,{className:"h-3.5 w-3.5 shrink-0"})]}):(0,e.jsx)("span",{}),' +
    '(0,e.jsxs)("a",{href:`https://map.naver.com/p/search/${encodeURIComponent(a.address)}`,target:"_blank",rel:"noreferrer",' +
    'className:"flex shrink-0 items-center gap-1 text-[#07877f]",children:["\\uC9C0\\uB3C4\\uC5D0\\uC11C \\uBCF4\\uAE30 ",(0,e.jsx)(T,{className:"h-4 w-4"})]})]})';
  return replaceOnce(s, oldFooter, newFooter);
});

// ═════════════════════════════ 2. 소개문 → "주요 사업" 목록 ═════════════════════════════
const BULLET_STYLE = '{marginTop:"9px",width:"6px",height:"6px",flexShrink:0,borderRadius:"9999px",background:"#07988f"}';
const LIST_STYLE = '{display:"grid",gap:"4px",listStyle:"none",padding:0,margin:"8px 0 0"}';
apply("주요 사업 목록 (서버)", "serverServices", (s) => s.includes("facility.highlights"), (s) => {
  const re = /facility\.content \? \/\* @__PURE__ \*\/ \(0, import_jsx_runtime\.jsx\)\("p", \{\s*className: "mt-3 [^"]*",\s*children: facility\.content\s*\}\) : null,/;
  const neu = [
    'facility.highlights && facility.highlights.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {',
    '\t\t\t\t\t\t\t\t\tclassName: "mt-4 border-t border-[#edf2f1] pt-3",',
    '\t\t\t\t\t\t\t\t\tchildren: [',
    '\t\t\t\t\t\t\t\t\t\t/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "text-xs font-black text-[#07877f]", children: "주요 사업" }),',
    '\t\t\t\t\t\t\t\t\t\t/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {',
    '\t\t\t\t\t\t\t\t\t\t\tclassName: "text-sm leading-6 text-[#31535a]",',
    `\t\t\t\t\t\t\t\t\t\t\tstyle: ${LIST_STYLE},`,
    '\t\t\t\t\t\t\t\t\t\t\tchildren: facility.highlights.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {',
    '\t\t\t\t\t\t\t\t\t\t\t\tclassName: "flex gap-2",',
    `\t\t\t\t\t\t\t\t\t\t\t\tchildren: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { "aria-hidden": "true", style: ${BULLET_STYLE} }), item]`,
    '\t\t\t\t\t\t\t\t\t\t\t}, i))',
    '\t\t\t\t\t\t\t\t\t\t})',
    '\t\t\t\t\t\t\t\t\t]',
    '\t\t\t\t\t\t\t\t}) : null,',
  ].join("\n");
  return replaceOnce(s, re, neu);
});
apply("주요 사업 목록 (브라우저)", "clientServices", (s) => s.includes("a.highlights"), (s) => {
  const old = 'a.content?(0,e.jsx)("p",{className:"mt-3 line-clamp-2 text-[11px] leading-5 text-[#8a9c9f]",children:a.content}):null';
  const neu =
    'a.highlights&&a.highlights.length?(0,e.jsxs)("div",{className:"mt-4 border-t border-[#edf2f1] pt-3",children:[' +
    `(0,e.jsx)("p",{className:"text-xs font-black text-[#07877f]",children:"${KO("주요 사업")}"}),` +
    `(0,e.jsx)("ul",{className:"text-sm leading-6 text-[#31535a]",style:${LIST_STYLE},children:a.highlights.map((h,i)=>(0,e.jsxs)("li",{className:"flex gap-2",children:[(0,e.jsx)("span",{"aria-hidden":"true",style:${BULLET_STYLE}}),h]},i))})]}):null`;
  return replaceOnce(s, old, neu);
});

// ═════════════════════════════ 3. 기관 목록: 필터·URL·검색·전화·자세히·안내 ═════════════════════════════
const TARGET_OPTIONS = ["전체", "노인", "장애인", "노인·장애인", "지역주민"];

/** 공용 함수 블록 (서버·브라우저 동일) */
const SHARED_FACILITY_FNS = `
function GcFacilityText(f) {
  return [f.name, f.detail, f.target, f.targetDetail, (f.services || []).join(" "), (f.tags || []).join(" "), (f.highlights || []).join(" ")].join(" ");
}
function GcApplyUrlFilters(setQuery, setCategory, setTarget, setTags) {
  try {
    const p = new URLSearchParams(window.location.search);
    const fromSession = sessionStorage.getItem("facilityQuery");
    sessionStorage.removeItem("facilityQuery");
    const q = p.get("q") ?? fromSession;
    if (q) setQuery(q);
    if (p.get("category")) setCategory(p.get("category"));
    if (p.get("target")) setTarget(p.get("target"));
    if (p.get("tags")) setTags(p.get("tags"));
  } catch (e) {}
}
`;

/** 이용대상 필터 행 + 상황 필터 해제 칩 (템플릿: __T__ 상태, __SET_T__, __TAGS__, __SET_TAGS__, __FAC__) */
const TARGET_ROW_TPL = `JSXS("div", {
  className: "mt-4 flex items-center gap-3 overflow-x-auto pb-1",
  children: [
    JSX("span", { className: "flex shrink-0 items-center gap-1.5 text-xs font-black text-[#71858a]", children: "이용대상" }),
    ${JSON.stringify(TARGET_OPTIONS)}.map((t) => JSXS("button", {
      onClick: () => __SET_T__(t),
      className: "shrink-0 rounded-full px-4 py-2 text-xs font-extrabold transition " + (__T__ === t ? "bg-[#103e46] text-white" : "border border-[#dbe9e6] bg-white text-[#49666d] hover:border-[#07988f]"),
      children: [t, " ", JSX("span", { className: "ml-1 opacity-65", children: t === "전체" ? __FAC__.length : __FAC__.filter((f) => f.target === t).length })]
    }, t)),
    __TAGS__ ? JSXS("button", {
      onClick: () => __SET_TAGS__(""),
      className: "shrink-0 rounded-full bg-[#fff0e7] px-4 py-2 text-xs font-extrabold text-[#c56239]",
      title: "상황 필터 해제",
      children: ["상황 필터: ", __TAGS__.split(",").join(" · "), " ✕"]
    }) : null
  ]
}), `;

/** 기관 상세 팝업 (공용 컴포넌트) */
const FACILITY_DIALOG_TPL = `
function GcFacilityDialog({ facility, onClose, sourceDate }) {
  REACT.useEffect(() => {
    if (!facility) return;
    const onKey = (ev) => { if (ev.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = prev; };
  }, [facility, onClose]);
  if (!facility) return null;
  const tel = facility.phone ? "tel:" + facility.phone.replace(/[^0-9+]/g, "") : "";
  const row = (label, value) => value ? JSXS("div", { className: "gc-dialog-row", children: [JSX("dt", { className: "text-xs font-black text-[#71858a]", children: label }), JSX("dd", { className: "text-sm leading-6 text-[#31535a]", children: value })] }) : null;
  return JSX("div", {
    role: "dialog", "aria-modal": "true", "aria-label": facility.name + " 상세 정보", onClick: onClose, className: "gc-dialog-backdrop",
    children: JSXS("div", {
      onClick: (ev) => ev.stopPropagation(), className: "gc-dialog",
      children: [
        JSXS("div", { className: "flex items-start justify-between gap-3", children: [
          JSX("div", { className: "flex flex-wrap gap-1.5", children: (facility.services || []).map((sv) => JSX("span", { className: "rounded-full bg-[#e5f6f2] px-3 py-1 text-[11px] font-black text-[#07877f]", children: sv }, sv)) }),
          JSX("button", { type: "button", onClick: onClose, "aria-label": "닫기", className: "gc-dialog-close", children: "✕" })
        ] }),
        JSX("h2", { className: "mt-3 text-2xl font-black text-[#173e47]", children: facility.name }),
        JSXS("dl", { className: "gc-dialog-list", children: [
          row("이용대상", facility.targetDetail || facility.target || "미기재"),
          row("서비스 세부", facility.detail),
          row("전화", tel ? JSX("a", { href: tel, className: "font-bold text-[#07877f]", children: facility.phone }) : "미기재"),
          row("주소", facility.address ? JSXS("span", { children: [facility.address, " ", JSX("a", { href: "https://map.naver.com/p/search/" + encodeURIComponent(facility.address), target: "_blank", rel: "noreferrer", className: "font-bold text-[#07877f]", children: "지도에서 보기 ↗" })] }) : "미기재"),
          row("홈페이지", facility.homepage ? JSX("a", { href: facility.homepage.startsWith("http") ? facility.homepage : "https://" + facility.homepage, target: "_blank", rel: "noreferrer", className: "font-bold text-[#07877f] break-all", children: facility.homepage.replace(/^https?:\\/\\//, "") }) : null),
          row("주요 사업", facility.highlights && facility.highlights.length ? JSX("ul", { className: "gc-dialog-ul", children: facility.highlights.map((h, i) => JSX("li", { children: h }, i)) }) : null),
          row("원문 (현황조사 자료)", facility.content ? JSX("p", { className: "gc-dialog-raw", children: facility.content }) : null)
        ] }),
        JSXS("p", { className: "mt-4 text-xs text-[#71858a]", children: ["자료 기준 ", sourceDate, " · 강남구 통합돌봄 서비스 현황조사 참여기관 목록. 정보가 실제와 다르면 강남구 통합돌봄 상담(02-3446-9736)으로 알려주세요."] })
      ]
    })
  });
}
`;

apply("기관 목록 필터·검색·전화·자세히 (서버)", "serverServices", (s) => s.includes("GcApplyUrlFilters"), (s) => {
  let out = s;
  // 3-1 URL 파라미터를 초기 상태가 아닌 effect 에서 적용 (서버·브라우저 첫 렌더를 같게 유지)
  out = must(out.replace(/const \[query, setQuery\] = \(0, import_react\.useState\)\(\(\) => \{\s*if \(typeof window === "undefined"\) return "";[\s\S]*?return fromUrl \?\? fromSession \?\? "";\s*\}\);/, 'const [query, setQuery] = (0, import_react.useState)("");'), s, "query 초기화");
  let prev = out;
  out = insertAfter(out, 'const [page, setPage] = (0, import_react.useState)(1);', [
    "",
    '\tconst [target, setTarget] = (0, import_react.useState)("전체");',
    '\tconst [tagFilter, setTagFilter] = (0, import_react.useState)("");',
    "\tconst [selected, setSelected] = (0, import_react.useState)(null);",
    "\t(0, import_react.useEffect)(() => { GcApplyUrlFilters(setQuery, setCategory, setTarget, setTagFilter); }, []);",
  ].join("\n"));
  out = must(out, prev, "상태 추가");
  // 3-2 필터 조건 + 검색 범위
  prev = out;
  out = out.replace(
    /const matchesNeighborhood = neighborhood === "전체 지역" \|\| neighborhoodOf\(facility\.address\) === neighborhood;\s*const haystack = `\$\{facility\.name\} \$\{facility\.target\} \$\{facility\.detail\} \$\{facility\.address\} \$\{facility\.services\.join\(" "\)\}`\.toLocaleLowerCase\("ko-KR"\);\s*return matchesCategory && matchesNeighborhood && \(!keyword \|\| haystack\.includes\(keyword\)\);/,
    'const matchesNeighborhood = neighborhood === "전체 지역" || neighborhoodOf(facility.address) === neighborhood;\n' +
    '\t\t\tconst matchesTarget = target === "전체" || facility.target === target;\n' +
    "\t\t\tconst matchesTags = !tagFilter || tagFilter.split(\",\").some((k) => GcFacilityText(facility).includes(k));\n" +
    '\t\t\tconst haystack = `${facility.name} ${facility.target} ${facility.detail} ${facility.address} ${facility.services.join(" ")} ${(facility.highlights || []).join(" ")} ${facility.content || ""}`.toLocaleLowerCase("ko-KR");\n' +
    "\t\t\treturn matchesCategory && matchesNeighborhood && matchesTarget && matchesTags && (!keyword || haystack.includes(keyword));",
  );
  out = must(out, prev, "필터 조건");
  prev = out; out = out.replace(/\}, \[\s*category,\s*neighborhood,\s*query\s*\]\);/, "}, [category, neighborhood, query, target, tagFilter]);"); out = must(out, prev, "useMemo deps");
  prev = out; out = out.replace(/\(0, import_react\.useEffect\)\(\(\) => setPage\(1\), \[\s*query,\s*category,\s*neighborhood\s*\]\);/, "(0, import_react.useEffect)(() => setPage(1), [query, category, neighborhood, target, tagFilter]);"); out = must(out, prev, "page reset deps");
  // 3-3 이용대상 필터 행 (서비스유형 행 앞)
  const row = toServer(TARGET_ROW_TPL).replace(/__SET_T__/g, "setTarget").replace(/__T__/g, "target").replace(/__SET_TAGS__/g, "setTagFilter").replace(/__TAGS__/g, "tagFilter").replace(/__FAC__/g, "FACILITIES");
  prev = out; out = out.replace(/\/\* @__PURE__ \*\/ \(0, import_jsx_runtime\.jsxs\)\("div", \{\s*className: "mt-5 flex items-center gap-3 overflow-x-auto pb-1",/, (m) => "/* @__PURE__ */ " + row + m); out = must(out, prev, "이용대상 행");
  // 3-4 요약 표시에 이용대상 포함
  prev = out; out = out.replace(/(" · ",\s*neighborhood)(\s*\]\s*\}\)\]\s*\}\),)/, '$1,\n\t\t\t\t\t\t\t\ttarget !== "전체" ? " · " + target : ""$2'); out = must(out, prev, "필터 요약");
  // 3-5 전화 tel 링크
  prev = out; out = replaceOnce(out, '/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: facility.phone })',
    'facility.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "tel:" + facility.phone.replace(/[^0-9+]/g, ""), className: "font-bold text-[#173e47]", children: facility.phone }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "전화 미기재" })'); out = must(out, prev, "전화 링크");
  // 3-6 "자세히" 버튼 (지도 링크 앞)
  prev = out; out = out.replace(/(\/\* @__PURE__ \*\/ \(0, import_jsx_runtime\.jsxs\)\("a", \{\s*href: `https:\/\/map\.naver\.com\/p\/search\/\$\{encodeURIComponent\(facility\.address\)\}`,)/,
    '/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", onClick: () => setSelected(facility), className: "gc-detail-btn", children: "자세히" }),\n\t\t\t\t\t\t\t\t\t\t$1'); out = must(out, prev, "자세히 버튼");
  // 3-7 팝업 마운트 (푸터 뒤)
  prev = out; out = out.replace(/(\/\* @__PURE__ \*\/ \(0, import_jsx_runtime\.jsx\)\(SiteFooter, \{\}\))(\s*\]\s*\}\);\s*\}\s*function Stat\()/,
    "$1,\n\t\t\t/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GcFacilityDialog, { facility: selected, onClose: () => setSelected(null), sourceDate: FACILITY_SOURCE_DATE })$2"); out = must(out, prev, "팝업 마운트");
  // 3-8 자료 기준일 · 수정 요청
  prev = out; out = replaceOnce(out, 'children: "검색 결과"', 'children: ["검색 결과 · 자료 기준 ", FACILITY_SOURCE_DATE]'); out = must(out, prev, "검색 결과 라벨");
  prev = out; out = replaceOnce(out, '" 기준 · 연락처와 주소가 확인된 기관만 표시했습니다."',
    '" 기준 · 연락처와 주소가 확인된 기관만 표시했습니다. 정보가 실제와 다르면 ",\n\t\t\t\t\t\t\t/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "tel:0234469736", className: "font-bold text-[#07877f]", children: "강남구 통합돌봄 상담 02-3446-9736" }),\n\t\t\t\t\t\t\t" 으로 알려주세요."'); out = must(out, prev, "데이터 안내");
  out = upsertBlock(out, "facility-fns", SHARED_FACILITY_FNS + toServer(FACILITY_DIALOG_TPL));
  return out;
});

apply("기관 목록 필터·검색·전화·자세히 (브라우저)", "clientServices", (s) => s.includes("GcApplyUrlFilters"), (s) => {
  if (!/\(0,d\.useState\)/.test(s) || !/\(0,e\.jsx\)/.test(s)) throw new Error("브라우저 services 번들의 React/JSX 식별자(d, e)가 예상과 다릅니다.");
  let out = s, prev;
  const 전체 = KO("전체");
  prev = out; out = replaceOnce(out,
    'let[s,i]=(0,d.useState)(()=>{if(typeof window>"u")return"";let a=new URLSearchParams(window.location.search).get("q"),t=sessionStorage.getItem("facilityQuery");return sessionStorage.removeItem("facilityQuery"),a??t??""})',
    'let[s,i]=(0,d.useState)("")'); out = must(out, prev, "query 초기화");
  prev = out; out = replaceOnce(out, "[l,p]=(0,d.useState)(1),", `[l,p]=(0,d.useState)(1),[gcT,gcSetT]=(0,d.useState)("${전체}"),[gcTags,gcSetTags]=(0,d.useState)(""),[gcSel,gcSetSel]=(0,d.useState)(null),`); out = must(out, prev, "상태 추가");
  prev = out; out = replaceOnce(out,
    `_=\`\${t.name} \${t.target} \${t.detail} \${t.address} \${t.services.join(" ")}\`.toLocaleLowerCase("ko-KR");return n&&y&&(!a||_.includes(a))})},[c,r,s])`,
    `_=\`\${t.name} \${t.target} \${t.detail} \${t.address} \${t.services.join(" ")} \${(t.highlights||[]).join(" ")} \${t.content||""}\`.toLocaleLowerCase("ko-KR"),gcM=gcT==="${전체}"||t.target===gcT,gcK=!gcTags||gcTags.split(",").some(k=>GcFacilityText(t).includes(k));return n&&y&&gcM&&gcK&&(!a||_.includes(a))})},[c,r,s,gcT,gcTags])`); out = must(out, prev, "필터 조건");
  prev = out; out = replaceOnce(out, "return(0,d.useEffect)(()=>p(1),[s,c,r]),", "return(0,d.useEffect)(()=>{GcApplyUrlFilters(i,u,gcSetT,gcSetTags)},[]),(0,d.useEffect)(()=>p(1),[s,c,r,gcT,gcTags]),"); out = must(out, prev, "effects");
  const row = toClient(TARGET_ROW_TPL, "e", "d").replace(/__SET_T__/g, "gcSetT").replace(/__T__/g, "gcT").replace(/__SET_TAGS__/g, "gcSetTags").replace(/__TAGS__/g, "gcTags").replace(/__FAC__/g, "h").replace(/\s*\n\s*/g, "");
  prev = out; out = insertBefore(out, '(0,e.jsxs)("div",{className:"mt-5 flex items-center gap-3 overflow-x-auto pb-1",children:[', row); out = must(out, prev, "이용대상 행");
  prev = out; out = replaceOnce(out, `," \\xB7 ",r]`, `," \\xB7 ",r,gcT!=="${전체}"?" \\xB7 "+gcT:""]`); out = must(out, prev, "필터 요약");
  prev = out; out = replaceOnce(out, '(0,e.jsx)("span",{children:a.phone})', `a.phone?(0,e.jsx)("a",{href:"tel:"+a.phone.replace(/[^0-9+]/g,""),className:"font-bold text-[#173e47]",children:a.phone}):(0,e.jsx)("span",{children:"${KO("전화 미기재")}"})`); out = must(out, prev, "전화 링크");
  prev = out; out = out.replace(/(\(0,e\.jsxs\)\("a",\{href:`https:\/\/map\.naver\.com\/p\/search\/\$\{encodeURIComponent\(a\.address\)\}`,target:"_blank",rel:"noreferrer",className:"flex shrink-0 items-center gap-1 text-\[#07877f\]")/,
    `(0,e.jsx)("button",{type:"button",onClick:()=>gcSetSel(a),className:"gc-detail-btn",children:"${KO("자세히")}"}),$1`); out = must(out, prev, "자세히 버튼");
  prev = out; out = out.replace(/,\(0,e\.jsx\)\(([A-Za-z$_]+),\{\}\)\]\}\)\}function ([A-Za-z$_]+)\(\{value/, (m, footer, statFn) => `,(0,e.jsx)(${footer},{}),(0,e.jsx)(GcFacilityDialog,{facility:gcSel,onClose:()=>gcSetSel(null),sourceDate:O})]})}function ${statFn}({value`); out = must(out, prev, "팝업 마운트");
  prev = out; out = replaceOnce(out, `children:"${KO("검색 결과")}"`, `children:["${KO("검색 결과 · 자료 기준 ")}",O]`); out = must(out, prev, "검색 결과 라벨");
  prev = out; out = out.replace(/O," \\uAE30\\uC900 \\xB7 ([^"]*)\\uD588\\uC2B5\\uB2C8\\uB2E4\."\]/, (m, mid) => `O," \\uAE30\\uC900 \\xB7 ${mid}\\uD588\\uC2B5\\uB2C8\\uB2E4. ${KO("정보가 실제와 다르면 ")}",(0,e.jsx)("a",{href:"tel:0234469736",className:"font-bold text-[#07877f]",children:"${KO("강남구 통합돌봄 상담 02-3446-9736")}"})," ${KO("으로 알려주세요.")}"]`); out = must(out, prev, "데이터 안내");
  out = upsertBlock(out, "facility-fns", SHARED_FACILITY_FNS + toClient(FACILITY_DIALOG_TPL, "e", "d"));
  return out;
});

// ═════════════════════════════ 4. 홈: 상황 카드 → 필터, 상담·문의 ═════════════════════════════
const SITUATION_QUERY = {
  "퇴원 후 돌봄": "tags=" + encodeURIComponent("방문진료,긴급돌봄,재택의료,건강주치의"),
  "혼자 사는 어르신": "target=" + encodeURIComponent("노인") + "&tags=" + encodeURIComponent("일상돌봄,마음돌봄,긴급돌봄,안부"),
  "거동이 불편한 분": "tags=" + encodeURIComponent("방문목욕,방문진료,장기요양보험,활동지원"),
  "가족 돌봄 부담": "tags=" + encodeURIComponent("장기요양보험,주간보호,데이케어,일시재가"),
  "생애 말기 돌봄": "tags=" + encodeURIComponent("재가암,호스피스,방문진료,마음돌봄"),
};
const SITUATION_BLOCK = `var GC_SITUATION_QUERY = ${JSON.stringify(SITUATION_QUERY)};`;

// 적용 여부는 상수 블록(//#gc-begin:situations) 존재로 판단 — 링크 코드만 남고 블록이 지워진 상태도 복구할 수 있게
apply("홈 상황 카드 → 필터 (서버)", "serverRoutes", (s) => s.includes("//#gc-begin:situations"), (s) => {
  let out = s;
  if (!out.includes("GC_SITUATION_QUERY[title]")) {
    const prev = out;
    out = out.replace(/situations\.map\(\(\{ title, desc, icon: Icon, tone, query: value \}\) => \/\* @__PURE__ \*\/ \(0, import_jsx_runtime\.jsxs\)\(Link, \{\s*to: "\/services",\s*className: ("group rounded-\[1\.6rem\][^"]*"),\s*onClick: \(\) => \{\s*if \(typeof window !== "undefined"\) sessionStorage\.setItem\("facilityQuery", value\);\s*\},/,
      (m, cls) => `situations.map(({ title, desc, icon: Icon, tone, query: value }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {\n\t\t\t\t\t\t\t\thref: "/services?" + (GC_SITUATION_QUERY[title] || "q=" + encodeURIComponent(value)),\n\t\t\t\t\t\t\t\tclassName: ${cls},`);
    out = must(out, prev, "상황 카드 링크");
  }
  return upsertBlock(out, "situations", SITUATION_BLOCK);
});
apply("홈 상황 카드 → 필터 (브라우저)", "clientRoutes", (s) => s.includes("//#gc-begin:situations"), (s) => {
  let out = s;
  if (!out.includes("GC_SITUATION_QUERY[e]")) {
    const prev = out;
    out = out.replace(/([A-Za-z_$]+)\.map\(\(\{title:e,desc:t,icon:n,tone:r,query:a\}\)=>\(0,N\.jsxs\)\(i,\{to:`\/services`,className:(`group rounded-\[1\.6rem\][^`]*`),onClick:\(\)=>\{typeof window<`u`&&sessionStorage\.setItem\(`facilityQuery`,a\)\},/,
      (m, arr, cls) => `${arr}.map(({title:e,desc:t,icon:n,tone:r,query:a})=>(0,N.jsxs)("a",{href:"/services?"+(GC_SITUATION_QUERY[e]||"q="+encodeURIComponent(a)),className:${cls},`);
    out = must(out, prev, "상황 카드 링크");
  }
  return upsertBlock(out, "situations", SITUATION_BLOCK);
});
apply("홈 '소식·문의' → '상담·문의' (서버)", "serverRoutes", (s) => !s.includes('" 소식·문의"'), (s) => replaceOnce(s, '" 소식·문의"', '" 상담·문의"'));
apply("홈 '소식·문의' → '상담·문의' (브라우저)", "clientRoutes", (s) => !s.includes("` 소식·문의`"), (s) => replaceOnce(s, "` 소식·문의`", "` 상담·문의`"));

// ═════════════════════════════ 4-2. 특화사업 7번: 강남 AI 포용케어 → 방문약물관리 ═════════════════════════════
// ※ 사업 세부 문구는 담당부서 확인 후 여기서 바꾸면 됨. (id 는 카드 key 로만 쓰여 그대로 둠)
const PROGRAM7 = {
  title: "방문약물관리",
  tagline: "약사가 집으로 찾아가 복약을 점검하는 안심 약물관리",
  target: ["여러 약을 함께 복용하는 65세 이상 어르신·만성질환자", "거동이 불편해 약국 방문이 어려운 재가 대상자"],
  support: ["약사 가정 방문 복약 상담 및 약물 점검 (중복·상호작용 확인)", "복약 일정표·약 달력 제공, 복약 순응도 관리", "의료기관·국민건강보험공단 다제약물관리사업 연계"],
  provider: ["강남구 통합돌봄 담당부서", "강남구약사회·지역 약국", "국민건강보험공단 (다제약물관리사업)"],
  caseStory: "열 가지가 넘는 약을 드시던 김ㅇㅇ어르신은 약사 방문 후 중복 처방 약을 정리하고 복약 달력을 쓰기 시작해 약 복용 실수가 크게 줄었습니다.",
};
const arrServer = (a) => "[\n" + a.map((s) => `\t\t\t${JSON.stringify(s)}`).join(",\n") + "\n\t\t]";
const arrClient = (a) => "[" + a.map((s) => "`" + s + "`").join(",") + "]";
apply("특화사업 7번 방문약물관리 (서버)", "serverRoutes", (s) => s.includes(`title: "${PROGRAM7.title}"`), (s) => {
  // replaceOnce 는 함수 치환을 쓰므로 $1 같은 참조가 안 됨 → 직접 함수로 조립
  const re = /(\t\tid: "ai-care",\n\t\tno: 7,\n)\t\ttitle: "[^"]*",\n\t\ttagline: "[^"]*",\n(\t\timage: "[^"]*",\n)\t\ttarget: \[[\s\S]*?\],\n\t\tsupport: \[[\s\S]*?\],\n\t\tprovider: \[[\s\S]*?\],\n\t\tcaseStory: "[^"]*"\n/;
  if (count(s, re) !== 1) return s;
  return s.replace(re, (m, head, image) => `${head}\t\ttitle: ${JSON.stringify(PROGRAM7.title)},\n\t\ttagline: ${JSON.stringify(PROGRAM7.tagline)},\n${image}\t\ttarget: ${arrServer(PROGRAM7.target)},\n\t\tsupport: ${arrServer(PROGRAM7.support)},\n\t\tprovider: ${arrServer(PROGRAM7.provider)},\n\t\tcaseStory: ${JSON.stringify(PROGRAM7.caseStory)}\n`);
});
apply("특화사업 7번 방문약물관리 (브라우저)", "clientRoutes", (s) => s.includes(`title:\`${PROGRAM7.title}\``), (s) => {
  const re = /(\{id:`ai-care`,no:7,)title:`[^`]*`,tagline:`[^`]*`,(image:`[^`]*`,)target:\[[^\]]*\],support:\[[^\]]*\],provider:\[[^\]]*\],caseStory:`[^`]*`\}/;
  if (count(s, re) !== 1) return s;
  return s.replace(re, (m, head, image) => `${head}title:\`${PROGRAM7.title}\`,tagline:\`${PROGRAM7.tagline}\`,${image}target:${arrClient(PROGRAM7.target)},support:${arrClient(PROGRAM7.support)},provider:${arrClient(PROGRAM7.provider)},caseStory:\`${PROGRAM7.caseStory}\`}`);
});
// 팝업 이미지의 크기 속성을 새 이미지(1200×900)에 맞춤
apply("특화사업 팝업 이미지 크기 (서버)", "serverRoutes", (s) => !s.includes("width: 1448,"), (s) => replaceOnce(s, "width: 1448,\n\t\t\t\t\t\theight: 1086", "width: 1200,\n\t\t\t\t\t\theight: 900"));
apply("특화사업 팝업 이미지 크기 (브라우저)", "clientRoutes", (s) => !s.includes("width:1448,height:1086"), (s) => replaceOnce(s, "width:1448,height:1086", "width:1200,height:900"));

// ═════════════════════════════ 5. 홈 정보나눔 섹션 (v2) ═════════════════════════════
const NEWS_COMPONENT = `
function GcNewsSection() { /* gc-news-v2 */
  const [state, setState] = REACT.useState({ items: [], loaded: false });
  REACT.useEffect(() => {
    fetch("/news.json", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then((d) => {
      const all = d && Array.isArray(d.items) ? d.items : [];
      const core = all.filter((n) => (n.relevance || 0) >= 2);
      setState({ items: (core.length >= 3 ? core : all).slice(0, 3), loaded: true });
    }).catch(() => setState({ items: [], loaded: true }));
  }, []);
  const fmt = (iso) => (iso || "").replace(/-/g, ".");
  const isNew = (iso) => iso && (Date.now() - new Date(iso).getTime()) < 7 * 86400000;
  const cards = state.items.length ? state.items.map((n) => JSXS("a", {
    href: n.link, target: "_blank", rel: "noreferrer", className: "gc-news-card rounded-2xl border border-[#dcebe8] bg-white p-5 transition hover:bg-[#eaf8f5]",
    children: [
      JSXS("p", { className: "flex flex-wrap items-center gap-2 text-xs font-bold text-[#07877f]", children: [fmt(n.date), n.dept ? JSX("span", { className: "text-[#71858a]", children: "· " + n.dept }) : null, isNew(n.date) ? JSX("span", { className: "gc-badge-new", children: "새 글" }) : null] }),
      JSX("h3", { className: "gc-fs15 font-black text-[#173e47] leading-6", children: n.title }),
      (n.tags || []).length ? JSX("p", { className: "flex flex-wrap gap-1.5", children: (n.tags || []).slice(0, 2).map((t) => JSX("span", { className: "rounded-full bg-[#fff0e7] px-2.5 py-0.5 text-[11px] font-extrabold text-[#c56239]", children: t }, t)) }) : null
    ]
  }, n.id)) : [JSX("div", {
    className: "rounded-2xl border border-[#dcebe8] bg-white p-5 text-sm text-[#6a7f84]", style: { gridColumn: "1 / -1" },
    children: state.loaded ? "아직 수집된 소식이 없습니다. 정보나눔 페이지에서 확인해 주세요." : "소식을 불러오는 중입니다…"
  }, "empty")];
  return JSX("section", {
    id: "info-share", className: "gc-news-section scroll-mt-32 bg-[#f7faf9]",
    children: JSXS("div", {
      className: "mx-auto max-w-7xl px-4 sm:px-6",
      children: [
        JSXS("div", {
          className: "gc-news-head",
          children: [
            JSXS("div", { children: [
              JSX("p", { className: "text-xs font-extrabold text-[#07877f]", children: "정보나눔" }),
              JSX("h2", { className: "mt-2 text-2xl font-black text-[#173e47] sm:text-3xl", children: "통합돌봄 소식" }),
              JSX("p", { className: "mt-2 text-sm text-[#6a7f84]", children: "보건복지부 보도자료 중 통합돌봄 관련 소식을 매일 자동으로 모아 보여드립니다." })
            ] }),
            JSX("a", { href: "/news", className: "gc-news-more rounded-full bg-[#103e46] px-4 py-3 text-sm font-bold text-white", children: "정보나눔 전체 보기 →" })
          ]
        }),
        JSX("div", { className: "gc-news-grid", children: cards })
      ]
    })
  });
}
`;
function replaceNewsComponent(s, code) {
  // v1 은 파일 끝에 마커 없이 붙어 있었음 → 그 함수 구간만 제거(다음 gc 블록 직전까지) 후 블록으로 다시 추가
  const v1 = s.indexOf("\nfunction GcNewsSection() {\n");
  if (v1 >= 0 && !s.includes("//#gc-begin:news")) {
    const next = s.indexOf("\n//#gc-begin:", v1 + 1);
    s = s.slice(0, v1) + "\n" + (next >= 0 ? s.slice(next) : "");
  }
  return upsertBlock(s, "news", code);
}
apply("홈 정보나눔 섹션 v2 (서버)", "serverRoutes", (s) => s.includes("gc-news-v2"), (s) => {
  let out = s;
  if (!out.includes("(GcNewsSection, {})")) {
    const idx = out.indexOf('id: "news"'); const sec = out.lastIndexOf('/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {', idx);
    if (idx < 0 || sec < 0) return s;
    out = out.slice(0, sec) + '/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GcNewsSection, {}),\n\t\t\t\t' + out.slice(sec);
  }
  return replaceNewsComponent(out, toServer(NEWS_COMPONENT));
});
apply("홈 정보나눔 섹션 v2 (브라우저)", "clientRoutes", (s) => s.includes("gc-news-v2"), (s) => {
  if (!/\bE\.useState\(/.test(s) || !/\(0,N\.jsx\)\(/.test(s)) throw new Error("브라우저 routes 번들의 React/JSX 식별자(E, N)가 예상과 다릅니다.");
  let out = s;
  if (!out.includes("(GcNewsSection,{})")) {
    const idx = out.indexOf("id:`news`"); const sec = out.lastIndexOf("(0,N.jsx)(`section`", idx);
    if (idx < 0 || sec < 0) return s;
    out = out.slice(0, sec) + "(0,N.jsx)(GcNewsSection,{})," + out.slice(sec);
  }
  return replaceNewsComponent(out, toClient(NEWS_COMPONENT, "N", "E"));
});

// ═════════════════════════════ 6. 헤더: 메뉴, 어두운 모드 / 글자 크게 ═════════════════════════════
apply("메뉴 정보나눔 (서버)", "serverMap", (s) => s.includes('href: "/news"'), (s) => {
  const anchor = '\t{\n\t\tlabel: "소식·문의",';
  return replaceOnce(s, anchor, '\t{\n\t\tlabel: "정보나눔",\n\t\thref: "/news"\n\t},\n' + anchor);
});
apply("메뉴 정보나눔 (브라우저)", "clientMap", (s) => s.includes("href:`/news`"), (s) => {
  const anchor = "{label:`소식·문의`,href:`/#news`}";
  return replaceOnce(s, anchor, "{label:`정보나눔`,href:`/news`}," + anchor);
});
apply("메뉴 '소식·문의' → '상담·문의' (서버)", "serverMap", (s) => !s.includes('label: "소식·문의"'), (s) => replaceOnce(s, 'label: "소식·문의"', 'label: "상담·문의"'));
apply("메뉴 '소식·문의' → '상담·문의' (브라우저)", "clientMap", (s) => !s.includes("label:`소식·문의`"), (s) => replaceOnce(s, "label:`소식·문의`", "label:`상담·문의`"));

// 테마·글자 크기 초기화 스크립트 (첫 화면 깜빡임을 줄이기 위해 헤더 맨 앞에서 실행)
export const GC_INIT_JS = "(function(){try{var d=document.documentElement,t=localStorage.getItem('gc-theme');if(t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches))d.classList.add('dark');if(localStorage.getItem('gc-font')==='big')d.classList.add('gc-big');window.__gcTheme=function(){var on=d.classList.toggle('dark');localStorage.setItem('gc-theme',on?'dark':'light');document.querySelectorAll('[data-gc-theme]').forEach(function(b){b.setAttribute('aria-pressed',on)})};window.__gcFont=function(){var on=d.classList.toggle('gc-big');localStorage.setItem('gc-font',on?'big':'normal');document.querySelectorAll('[data-gc-font]').forEach(function(b){b.setAttribute('aria-pressed',on)})}}catch(e){}})();";
// v1(아이콘만) 툴바 — 제거용으로 원문을 보관
const LEGACY_TOOLBAR_TPL = `JSX("button", { type: "button", "data-gc-theme": "1", onClick: () => window.__gcTheme && window.__gcTheme(), className: "gc-tool-btn", "aria-label": "어두운 모드 전환", title: "어두운 모드", children: JSX("span", { className: "gc-theme-icon", "aria-hidden": "true" }) }), JSX("button", { type: "button", "data-gc-font": "1", onClick: () => window.__gcFont && window.__gcFont(), className: "gc-tool-btn", "aria-label": "글자 크게 전환", title: "글자 크게", children: "가+" }), `;
// v2: 아이콘 + 글자 라벨. 데스크톱은 헤더 우측, 모바일은 햄버거 메뉴 안
const THEME_BTN = (extra) => `JSX("button", { type: "button", "data-gc-theme": "1", onClick: () => window.__gcTheme && window.__gcTheme(), className: "gc-tool-btn${extra}", "aria-label": "어두운 화면 켜기/끄기", children: [JSX("span", { className: "gc-theme-icon", "aria-hidden": "true" }), "어두운 화면"] })`;
const FONT_BTN = (extra) => `JSX("button", { type: "button", "data-gc-font": "1", onClick: () => window.__gcFont && window.__gcFont(), className: "gc-tool-btn${extra}", "aria-label": "큰 글씨 켜기/끄기", children: [JSX("span", { className: "gc-font-icon", "aria-hidden": "true", children: "가" }), "큰 글씨"] })`;
const TOOLBAR_TPL = `JSX("div", { className: "gc-tools-desktop", role: "group", "aria-label": "화면 설정", children: [${THEME_BTN("")}, ${FONT_BTN("")}] }), `;
const MOBILE_TOOLS_TPL = `JSX("div", { className: "gc-tools-mobile", role: "group", "aria-label": "화면 설정", children: [${THEME_BTN(" gc-tool-btn-wide")}, ${FONT_BTN(" gc-tool-btn-wide")}] }), `;
const INIT_SCRIPT_TPL = `JSX("script", { dangerouslySetInnerHTML: { __html: ${JSON.stringify(GC_INIT_JS)} } }), `;
// JSXS 로 바꿔야 하는 곳: children 이 배열인 button/div → toServer/toClient 는 JSX( 만 치환하므로 여기서 jsxs 로 미리 표기
const useJsxs = (t) => t.replace(/JSX\("(button|div)", \{ ([^}]*children: \[)/g, 'JSXS("$1", { $2');

apply("헤더 어두운 화면·큰 글씨 버튼 v2 (서버)", "serverMap", (s) => s.includes("gc-tools-desktop"), (s) => {
  let out = s, prev;
  if (!out.includes("gc-theme")) {
    prev = out; out = out.replace(/(\(0, import_jsx_runtime\.jsxs\)\("header", \{\s*className: "sticky top-0 z-50 border-b border-\[#dcebe8\] bg-white\/95 backdrop-blur",\s*children: \[)/, (m) => m + "\n\t\t\t/* @__PURE__ */ " + toServer(INIT_SCRIPT_TPL).trim()); out = must(out, prev, "초기화 스크립트");
  }
  const legacy = "/* @__PURE__ */ " + toServer(LEGACY_TOOLBAR_TPL).trim() + "\n\t\t\t\t\t";
  if (out.includes(legacy)) out = out.split(legacy).join("");
  prev = out; out = out.replace(/(\/\* @__PURE__ \*\/ \(0, import_jsx_runtime\.jsx\)\("button", \{\s*type: "button",\s*onClick: \(\) => setOpen\(!open\),)/, (m) => "/* @__PURE__ */ " + toServer(useJsxs(TOOLBAR_TPL)).trim() + "\n\t\t\t\t\t" + m); out = must(out, prev, "데스크톱 툴바");
  prev = out; out = out.replace(/(\/\* @__PURE__ \*\/ \(0, import_jsx_runtime\.jsxs\)\("a", \{\s*href: "tel:0234469736",\s*className: "mt-2 flex items-center gap-2 rounded-xl bg-\[#103e46\])/, (m) => "/* @__PURE__ */ " + toServer(useJsxs(MOBILE_TOOLS_TPL)).trim() + "\n\t\t\t\t" + m); out = must(out, prev, "모바일 메뉴 툴");
  return out;
});
apply("헤더 어두운 화면·큰 글씨 버튼 v2 (브라우저)", "clientMap", (s) => s.includes("gc-tools-desktop"), (s) => {
  let out = s, prev;
  if (!out.includes("gc-theme")) {
    prev = out; out = insertAfter(out, "(0,x.jsxs)(`header`,{className:`sticky top-0 z-50 border-b border-[#dcebe8] bg-white/95 backdrop-blur`,children:[", toClient(INIT_SCRIPT_TPL, "x", "").replace(/\s*\n\s*/g, "")); out = must(out, prev, "초기화 스크립트");
  }
  const legacy = toClient(LEGACY_TOOLBAR_TPL, "x", "").replace(/\s*\n\s*/g, "");
  if (out.includes(legacy)) out = out.split(legacy).join("");
  prev = out; out = insertBefore(out, "(0,x.jsx)(`button`,{type:`button`,onClick:()=>t(!e),className:`grid h-11 w-11", toClient(useJsxs(TOOLBAR_TPL), "x", "").replace(/\s*\n\s*/g, "")); out = must(out, prev, "데스크톱 툴바");
  prev = out; out = insertBefore(out, "(0,x.jsxs)(`a`,{href:`tel:0234469736`,className:`mt-2 flex items-center gap-2 rounded-xl bg-[#103e46]", toClient(useJsxs(MOBILE_TOOLS_TPL), "x", "").replace(/\s*\n\s*/g, "")); out = must(out, prev, "모바일 메뉴 툴");
  return out;
});

// ═════════════════════════════ 6-2. 헤더 로고를 투명 배경 PNG 로 교체 ═════════════════════════════
// 원본 로고는 흰 배경이라 mix-blend-multiply 로 숨기고 있었음 → 어두운 모드에서 로고가 어둡게 눌림.
// tools/make-logo-transparent.mjs 가 만든 public/logo.png 의 내용으로 번들 속 data URI 를 바꾼다.
const LOGO_FILE = path.join(ROOT, "public", "logo.png");
const LOGO_DATA_URI = existsSync(LOGO_FILE) ? "data:image/png;base64," + readFileSync(LOGO_FILE).toString("base64") : "";
const LOGO_RE = /data:image\/png;base64,[A-Za-z0-9+/=]{200,}/g;
function swapLogo(s) {
  const uris = [...new Set(s.match(LOGO_RE) || [])];
  if (uris.length !== 1) throw new Error(`로고 data URI 가 ${uris.length}개 발견됨 (1개여야 함).`);
  return s.split(uris[0]).join(LOGO_DATA_URI);
}
for (const [label, key] of [["로고 투명 배경 (서버)", "serverMap"], ["로고 투명 배경 (브라우저)", "clientMap"]]) {
  apply(label, key, (s) => !LOGO_DATA_URI || s.includes(LOGO_DATA_URI), swapLogo);
}

// ═════════════════════════════ 7. 스타일시트: 대비·줄바꿈·글자 크기·어두운 모드 ═════════════════════════════
// Tailwind 가 만든 클래스명을 CSS 선택자로: 영문·숫자·_·- 이외의 문자(괄호, 쉼표, #, /, : 등)는 모두 역슬래시로 이스케이프
const cssSel = (cls) => "." + cls.replace(/[^A-Za-z0-9_-]/g, (c) => "\\" + c);
const hoverSel = (cls) => cssSel(cls) + ":hover"; // 클래스명에 hover: 접두어가 포함된 경우
function rule(prefix, classes, decl) {
  return classes.map((c) => `${prefix}${c.startsWith("hover:") ? hoverSel(c) : cssSel(c)}{${decl}}`).join("\n");
}
const DARK = {
  bgPage: "#0b1517", bgCard: "#111f23", bgNavy: "#0d2a30", bgMint: "#143331", bgWarm: "#2a221b", bgPurple: "#22223a", bgRose: "#33202a",
  ink: "#e7f1f0", ink2: "#cbdad8", muted: "#a3b5b8", teal: "#62d6cb", orange: "#ffa27a", line: "#274044", line2: "#3d7570",
};
const DARK_CSS = [
  "html.dark{color-scheme:dark}",
  `html.dark body{background:${DARK.bgPage};color:${DARK.ink}}`,
  rule("html.dark ", ["bg-white"], `background-color:${DARK.bgCard}`),
  rule("html.dark ", ["bg-white/95", "bg-white/92"], "background-color:rgba(17,31,35,.95)"),
  rule("html.dark ", ["bg-white/80", "bg-white/70"], "background-color:rgba(17,31,35,.85)"),
  rule("html.dark ", ["bg-[#fffdf9]", "bg-[#f7faf9]", "bg-[#fbfdfc]", "bg-[#f5f8f7]"], `background-color:${DARK.bgPage}`),
  rule("html.dark ", ["bg-[#103e46]", "bg-[#173e47]"], `background-color:${DARK.bgNavy}`),
  rule("html.dark ", ["bg-[#eef7f5]", "bg-[#e5f6f2]", "bg-[#e6f7f4]", "bg-[#dff5f1]", "bg-[#e3f8f4]", "bg-[#e8f5f1]", "bg-[#eef8f3]", "bg-[#f1faf7]", "bg-[#e7faf6]", "hover:bg-[#eaf8f5]", "hover:bg-[#eaf5f2]"], `background-color:${DARK.bgMint}`),
  rule("html.dark ", ["bg-[#fff0e7]", "bg-[#fff1e9]", "bg-[#fff4ec]", "bg-[#fff5ec]", "bg-[#fff7ef]", "bg-[#fffaf3]", "bg-[#fff5d9]", "bg-[#fff3cf]", "bg-[#f5f1e7]"], `background-color:${DARK.bgWarm}`),
  rule("html.dark ", ["bg-[#ffc9ac]"], "background-color:#6b3d27"),
  rule("html.dark ", ["bg-[#eeeefe]", "bg-[#ececfc]"], `background-color:${DARK.bgPurple}`),
  rule("html.dark ", ["bg-[#fdebed]"], `background-color:${DARK.bgRose}`),
  rule("html.dark ", ["bg-[#a9e3d9]"], "background-color:#1f5f5a"),
  rule("html.dark ", ["bg-[linear-gradient(120deg,#e7faf6_0%,#f4fbef_54%,#fff6ec_100%)]"], "background-image:linear-gradient(120deg,#0f2a2a 0%,#0d2420 54%,#221a14 100%)"),
  rule("html.dark ", ["text-[#173e47]", "text-[#103e46]"], `color:${DARK.ink}`),
  rule("html.dark ", ["text-[#31535a]", "text-[#49666d]", "text-[#4e6d74]", "text-[#536b70]", "text-[#547179]"], `color:${DARK.ink2}`),
  rule("html.dark ", ["text-[#6a7f84]", "text-[#71858a]", "text-[#657c82]", "text-[#8a9c9f]", "text-[#9aabad]"], `color:${DARK.muted}`),
  rule("html.dark ", ["text-[#07877f]", "text-[#07988f]", "hover:text-[#07988f]", "hover:text-[#07877f]"], `color:${DARK.teal}`),
  rule("html.dark ", ["text-[#d46a3b]", "text-[#c56239]", "text-[#c95635]"], `color:${DARK.orange}`),
  rule("html.dark ", ["text-[#6659b8]"], "color:#b2a8ff"),
  rule("html.dark ", ["text-[#a8750b]"], "color:#e8bd57"),
  rule("html.dark ", ["text-[#bd5262]"], "color:#ff95a6"),
  rule("html.dark ", ["text-[#87634f]"], "color:#d9b8a2"),
  rule("html.dark ", ["border-[#dbe9e6]", "border-[#dcebe8]", "border-[#edf2f1]", "border-[#e5eeeb]", "border-[#e3ecea]", "border-[#e1ece9]", "border-[#e1e8e2]", "border-[#dfe8e6]", "border-[#d9eee9]", "border-[#d7ebe7]", "border-[#f0ddd0]", "border-white"], `border-color:${DARK.line}`),
  rule("html.dark ", ["border-[#bde5de]", "border-[#b9dcd6]", "border-[#b8d7d2]", "border-[#a9dcd5]", "border-[#9edbd3]", "border-[#07988f]"], `border-color:${DARK.line2}`),
  rule("html.dark ", ["hover:border-[#9edbd3]", "hover:border-[#07988f]", "hover:border-[#8fd4ca]"], "border-color:#5aa9a1"),
  "html.dark .mix-blend-multiply{mix-blend-mode:normal}", // 투명 로고는 합성 없이 그대로 표시
  "html.dark input,html.dark select{color:inherit}",
  "html.dark input::placeholder{color:#7f9397}",
  "html.dark .gc-tool-btn{border-color:#274044;color:#e7f1f0;background:#111f23}",
  "html.dark .gc-tool-btn[data-gc-theme],html.dark.gc-big .gc-tool-btn[data-gc-font]{background:#62d6cb;color:#0b1517;border-color:#62d6cb}",
  "html.dark .gc-tool-btn[data-gc-theme] .gc-theme-icon{background:#0b1517;box-shadow:inset -4px -4px 0 0 #62d6cb}",
  "html.dark .gc-dialog{background:#111f23;color:#e7f1f0}",
  "html.dark .gc-dialog-close{border-color:#274044;color:#e7f1f0}",
  "html.dark .gc-dialog-raw{background:#0b1517;color:#a3b5b8}",
  "html.dark .gc-detail-btn{background:#143331;color:#62d6cb}",
  "html.dark .gc-badge-new{background:#4a2a1a;color:#ffb48f}",
  "html.dark .gc-theme-icon{background:#e7f1f0;box-shadow:inset -4px -4px 0 0 #111f23}",
].join("\n");

const EXTRA_CSS = `
/* gc-extra v5 : 아래 블록은 tools/patch-ui.mjs 가 생성·갱신합니다 */
main :where(h1,h2,h3,h4,p,li,dd){word-break:keep-all;overflow-wrap:anywhere}
.text-\\[\\#6a7f84\\]{color:#516a70}.text-\\[\\#71858a\\]{color:#566f76}.text-\\[\\#657c82\\]{color:#4f666c}.text-\\[\\#8a9c9f\\]{color:#5c7178}.text-\\[\\#9aabad\\]{color:#6b8085}.text-\\[\\#c56239\\]{color:#b3502a}.text-\\[\\#07877f\\]{color:#077b74}
.text-\\[10px\\]{font-size:11px}.text-\\[11px\\]{font-size:12px}
ul.text-sm.leading-6.text-\\[\\#31535a\\]{font-size:15px;line-height:1.65}
.gc-fs15{font-size:15px}
html.gc-big{font-size:112.5%}
html.gc-big .text-\\[10px\\]{font-size:12.5px}html.gc-big .text-\\[11px\\]{font-size:13.5px}html.gc-big .text-\\[13px\\]{font-size:15px}
html.gc-big ul.text-sm.leading-6.text-\\[\\#31535a\\]{font-size:17px}html.gc-big .gc-fs15{font-size:17px}
.gc-tools-desktop{display:none;align-items:center;gap:8px;margin-left:8px}
@media (min-width:1024px){.gc-tools-desktop{display:flex}}
.gc-tools-mobile{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
@media (min-width:640px){.gc-tools-mobile{grid-column:span 2}}
.gc-tool-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;height:44px;padding:0 14px;border-radius:12px;border:1px solid #dcebe8;color:#173e47;font-weight:800;font-size:14px;background:#fff;cursor:pointer;line-height:1;white-space:nowrap;font-family:inherit}
.gc-tool-btn-wide{height:48px;font-size:15px}
.gc-theme-icon{display:block;width:16px;height:16px;border-radius:50%;background:#173e47;box-shadow:inset -4px -4px 0 0 #fff;flex-shrink:0}
.gc-font-icon{display:inline-grid;place-items:center;width:20px;height:20px;border-radius:6px;border:1.5px solid currentColor;font-size:12px;font-weight:900;flex-shrink:0}
html.dark .gc-tool-btn[data-gc-theme],html.gc-big .gc-tool-btn[data-gc-font]{background:#103e46;color:#fff;border-color:#103e46}
html.dark .gc-tool-btn[data-gc-theme] .gc-theme-icon{background:#fff;box-shadow:inset -4px -4px 0 0 #103e46}
html.dark .gc-tool-btn[data-gc-theme]::after,html.gc-big .gc-tool-btn[data-gc-font]::after{content:" 켜짐";font-weight:600;opacity:.85}
.gc-detail-btn{flex-shrink:0;border-radius:9999px;background:#eef7f5;padding:6px 12px;color:#077b74;font-weight:900;font-size:12px;cursor:pointer;border:0}
.gc-dialog-backdrop{position:fixed;inset:0;z-index:100;background:rgba(16,62,70,.55);display:flex;align-items:center;justify-content:center;padding:16px}
.gc-dialog{background:#fff;color:#173e47;border-radius:24px;width:100%;max-width:720px;max-height:90vh;overflow:auto;padding:24px;box-shadow:0 30px 80px -30px rgba(16,62,70,.6)}
.gc-dialog-close{flex-shrink:0;width:40px;height:40px;border-radius:12px;border:1px solid #dcebe8;background:transparent;color:#173e47;font-size:16px;cursor:pointer}
.gc-dialog-list{display:grid;gap:12px;margin:18px 0 0}
.gc-dialog-row{display:grid;gap:4px}
.gc-dialog-ul{margin:0;padding-left:18px;display:grid;gap:4px}
.gc-dialog-raw{margin:0;max-height:200px;overflow:auto;border-radius:12px;background:#f7faf9;padding:12px;font-size:13px;line-height:1.7;color:#516a70;white-space:pre-line}
.gc-news-section{padding:56px 0}
.gc-news-head{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:16px}
.gc-news-more{text-decoration:none}
.gc-news-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-top:24px}
.gc-news-card{display:flex;flex-direction:column;gap:8px;text-decoration:none}
.gc-news-card h3{margin:0}.gc-news-card p{margin:0}
.gc-badge-new{border-radius:9999px;background:#fff0e7;padding:1px 8px;font-size:11px;font-weight:900;color:#b3502a}
${DARK_CSS}
/* gc-extra end */
`;
apply("스타일시트 확장 (대비·줄바꿈·글자 크게·어두운 모드)", "styles", (s) => s.includes("/* gc-extra v5 "), (s) => {
  const re = /\n\/\* gc-extra v\d+ [\s\S]*?\/\* gc-extra end \*\/\n/;
  return re.test(s) ? s.replace(re, () => EXTRA_CSS) : s + "\n" + EXTRA_CSS;
});

console.log((CHECK ? "UI 패치 상태" : "UI 패치 결과") + "\n" + results.join("\n"));
if (!CHECK) {
  for (const k of changed) writeFileSync(FILES[k], src[k]);
  if (changed.size) console.log(`\n✔ ${changed.size}개 파일 수정. 다음 단계: npm run data (파일명·etag 갱신)`);
  else console.log("\n변경 없음.");
}
