#!/usr/bin/env node
/**
 * 로고 PNG 의 흰 배경을 투명하게 바꿈 (외부 라이브러리 없이 PNG 를 직접 해석)
 *
 *   node tools/make-logo-transparent.mjs            public/logo.png 을 처리해 public/logo.png, client/logo.png 로 저장
 *   node tools/make-logo-transparent.mjs 입력.png   다른 파일을 입력으로 사용
 *
 * 배경: 사이트 헤더 로고가 흰 배경 PNG 라서 mix-blend-multiply 로 배경을 숨기고 있었는데,
 *       어두운 모드에서는 곱하기 합성 때문에 로고 전체가 어둡게 눌려 보이지 않는다.
 *       배경을 진짜 투명으로 만들고(이 스크립트), 어두운 모드에서는 합성을 끄면(patch-ui.mjs) 해결된다.
 * 지원: 8비트 RGB/RGBA, 비인터레이스 PNG. 처리 결과는 항상 8비트 RGBA 로 저장.
 */
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { inflateSync, deflateSync } from "node:zlib";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SIG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

// ───── CRC32 (PNG 청크용) ─────
const CRC_TABLE = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c; });
const crc32 = (buf) => { let c = -1; for (const b of buf) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ -1) >>> 0; };

export function decodePng(buf) {
  if (!buf.subarray(0, 8).equals(SIG)) throw new Error("PNG 파일이 아닙니다.");
  let pos = 8, width = 0, height = 0, bitDepth = 0, colorType = 0, interlace = 0;
  const idat = [];
  while (pos < buf.length) {
    const len = buf.readUInt32BE(pos); const type = buf.toString("latin1", pos + 4, pos + 8); const data = buf.subarray(pos + 8, pos + 8 + len);
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); bitDepth = data[8]; colorType = data[9]; interlace = data[12]; }
    else if (type === "IDAT") idat.push(data);
    else if (type === "IEND") break;
    pos += 12 + len;
  }
  if (bitDepth !== 8 || interlace !== 0 || ![2, 6].includes(colorType)) throw new Error(`지원하지 않는 PNG 형식입니다 (bitDepth=${bitDepth}, colorType=${colorType}, interlace=${interlace}). 8비트 RGB/RGBA 비인터레이스만 지원.`);
  const bpp = colorType === 6 ? 4 : 3;
  const raw = inflateSync(Buffer.concat(idat));
  const stride = width * bpp;
  const out = Buffer.alloc(width * height * 4);
  let prev = Buffer.alloc(stride), p = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[p++]; const line = Buffer.from(raw.subarray(p, p + stride)); p += stride;
    for (let i = 0; i < stride; i++) {
      const a = i >= bpp ? line[i - bpp] : 0, b = prev[i], c = i >= bpp ? prev[i - bpp] : 0;
      let v = line[i];
      if (filter === 1) v += a; else if (filter === 2) v += b; else if (filter === 3) v += (a + b) >> 1;
      else if (filter === 4) { const pa = Math.abs(b - c), pb = Math.abs(a - c), pc = Math.abs(a + b - 2 * c); v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c; }
      line[i] = v & 0xff;
    }
    for (let x = 0; x < width; x++) {
      const s = x * bpp, d = (y * width + x) * 4;
      out[d] = line[s]; out[d + 1] = line[s + 1]; out[d + 2] = line[s + 2]; out[d + 3] = bpp === 4 ? line[s + 3] : 255;
    }
    prev = line;
  }
  return { width, height, rgba: out };
}

export function encodePng({ width, height, rgba }) {
  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) { raw[y * (stride + 1)] = 0; rgba.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride); }
  const chunk = (type, data) => { const t = Buffer.from(type, "latin1"); const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(Buffer.concat([t, data]))); return Buffer.concat([len, t, data, crc]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4); ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([SIG, chunk("IHDR", ihdr), chunk("IDAT", deflateSync(raw, { level: 9 })), chunk("IEND", Buffer.alloc(0))]);
}

/**
 * "흰색을 투명도로" (GIMP color-to-alpha 방식)
 * 각 픽셀을 「원래 색 F 가 알파 a 로 흰 배경 위에 얹힌 결과」로 보고 a 와 F 를 되돌려 계산한다.
 *   관찰색 C = a·F + (1-a)·255  →  a = max(채널별 (255-C)/255),  F = (C - 255·(1-a)) / a
 * 이렇게 하면 흰 배경과 섞인 가장자리(안티에일리어싱) 픽셀도 원래 색으로 복원되어
 * 어두운 배경에서 흰 테두리(헤일로)가 남지 않는다.
 */
export function whiteToTransparent(img) {
  const { rgba } = img;
  for (let i = 0; i < rgba.length; i += 4) {
    const r = rgba[i], g = rgba[i + 1], b = rgba[i + 2], a0 = rgba[i + 3] / 255;
    const a = Math.max((255 - r) / 255, (255 - g) / 255, (255 - b) / 255);
    if (a <= 0.004) { rgba[i + 3] = 0; continue; }
    const unblend = (c) => Math.max(0, Math.min(255, Math.round((c - 255 * (1 - a)) / a)));
    rgba[i] = unblend(r); rgba[i + 1] = unblend(g); rgba[i + 2] = unblend(b);
    rgba[i + 3] = Math.round(255 * Math.min(1, a) * a0);
  }
  return img;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  // 기본 입력은 원본 백업(흰 배경 버전). 이미 투명 처리된 파일을 다시 처리하지 않도록.
  const backup = path.join(ROOT, "data", "backup", "logo-original.png");
  const input = process.argv[2] ? path.resolve(process.argv[2]) : existsSync(backup) ? backup : path.join(ROOT, "public", "logo.png");
  const img = whiteToTransparent(decodePng(readFileSync(input)));
  const png = encodePng(img);
  const transparent = [...Array(img.width * img.height).keys()].filter((i) => img.rgba[i * 4 + 3] === 0).length;
  for (const out of [path.join(ROOT, "public", "logo.png"), path.join(ROOT, "client", "logo.png")]) { if (existsSync(path.dirname(out))) writeFileSync(out, png); }
  console.log(`✔ 로고 ${img.width}x${img.height}: 투명 픽셀 ${Math.round((transparent / (img.width * img.height)) * 100)}% → public/logo.png, client/logo.png (${png.length} bytes)`);
}
