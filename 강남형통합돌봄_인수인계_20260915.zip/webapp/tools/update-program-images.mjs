#!/usr/bin/env node
/**
 * 7대 특화사업 카드 이미지 교체 도구
 *
 *   node tools/update-program-images.mjs                 상위 폴더의 "사진폴더" 사진을 특화사업에 맞춰 교체
 *   node tools/update-program-images.mjs --dir 경로      다른 폴더 지정
 *   node tools/update-program-images.mjs --dry-run       바뀔 내용만 출력
 *
 * 하는 일
 *  1. 사진을 사업 번호에 맞춰 찾음 (파일명 키워드로 매칭, 아래 PROGRAMS 표)
 *  2. macOS 내장 sips 로 4:3 비율 1200×900 JPEG(품질 82)로 변환 → public/assets/program-N-<slug>-<hash>.jpg
 *  3. 서버 코드·브라우저 번들·자산 테이블(server/index.mjs, index.js)의 옛 이미지 경로를 새 경로로 바꾸고 옛 파일 삭제
 *  4. client/assets 를 public/assets 와 동일하게 맞춤
 *
 * 실행 후 `npm run data` 로 청크 파일명·etag 를 갱신할 것.
 * (원본 PNG 는 카드 표시 크기보다 훨씬 커서 각 2MB 였음 → 약 60~90KB 로 줄어든다)
 */
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, unlinkSync, writeFileSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const args = process.argv.slice(2);
const DRY = args.includes("--dry-run");
const dirArg = args.indexOf("--dir") >= 0 ? args[args.indexOf("--dir") + 1] : null;
const PHOTO_DIR = dirArg ? path.resolve(dirArg) : path.resolve(ROOT, "..", "사진폴더");
const PUB = path.join(ROOT, "public", "assets");
const CLI = path.join(ROOT, "client", "assets");
const WIDTH = 1200, HEIGHT = 900, QUALITY = 82;

// 사업 번호 → 출력 파일 이름(slug) 과 사진 파일명에서 찾을 키워드(먼저 맞는 것 사용)
const PROGRAMS = [
  { no: 1, slug: "smart-house", keys: ["시니어하우스", "시니어 하우스", "스마트시니어"] },
  { no: 2, slug: "health-center", keys: ["건강증진", "지원센터"] },
  { no: 3, slug: "discharge", keys: ["퇴원"] },
  { no: 4, slug: "hospice", keys: ["호스피스"] },
  { no: 5, slug: "exercise", keys: ["방문운동", "운동"] },
  { no: 6, slug: "home-visit", keys: ["방문진료", "진료"] },
  { no: 7, slug: "medication", keys: ["약물", "복약", "AI", "포용"] },
];

const nfc = (s) => s.normalize("NFC");
const fail = (m) => { console.error("\n✖ " + m + "\n"); process.exit(1); };
const etagOf = (buf) => `"${buf.length.toString(16)}-${createHash("sha1").update(buf).digest("base64").slice(0, 27)}"`;
const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

if (!existsSync(PHOTO_DIR)) fail(`사진 폴더를 찾을 수 없습니다: ${PHOTO_DIR}`);
const photos = readdirSync(PHOTO_DIR).filter((f) => /\.(jpe?g|png|webp|heic)$/i.test(f) && !f.startsWith("."));

// 현재 번들에서 사업별 이미지 경로 찾기 (image: "/assets/program-…" 순서 = 사업 번호 순서)
const SSR = path.join(ROOT, "server", "_ssr");
const one = (dir, re) => { const l = readdirSync(dir).filter((f) => re.test(f)); if (l.length !== 1) fail(`${dir} 에서 ${re} 파일이 ${l.length}개`); return path.join(dir, l[0]); };
const serverRoutes = one(SSR, /^routes-.*\.mjs$/);
const clientRoutes = one(PUB, /^routes-.*\.js$/);
const serverSrc = readFileSync(serverRoutes, "utf8");
const currentImages = [...serverSrc.matchAll(/\n\t\tno: (\d+),\n\t\ttitle: "[^"]*",\n\t\ttagline: "[^"]*",\n\t\timage: "(\/assets\/[^"]+)"/g)].map((m) => ({ no: Number(m[1]), image: m[2] }));
if (currentImages.length !== 7) fail(`서버 코드에서 특화사업 이미지 7개를 찾지 못했습니다 (${currentImages.length}개).`);

const plan = [];
for (const p of PROGRAMS) {
  const photo = photos.find((f) => p.keys.some((k) => nfc(f).toLowerCase().includes(k.toLowerCase())));
  const cur = currentImages.find((c) => c.no === p.no);
  if (!photo) { console.log(`  - ${p.no}번(${p.slug}): 맞는 사진이 없어 건너뜀`); continue; }
  plan.push({ ...p, photo: path.join(PHOTO_DIR, photo), photoName: nfc(photo), oldPath: cur.image });
}
if (!plan.length) fail("교체할 사진이 없습니다.");

// 변환 (sips: 리샘플 후 중앙 4:3 크롭)
function convert(src, outFile) {
  const tmp = path.join(tmpdir(), `gc-program-${Date.now()}-${Math.random().toString(36).slice(2)}.png`);
  const [w, h] = execFileSync("sips", ["-g", "pixelWidth", "-g", "pixelHeight", src]).toString().match(/pixel(?:Width|Height): (\d+)/g).map((s) => Number(s.split(": ")[1]));
  // 짧은 쪽 기준으로 4:3 프레임을 채우도록 리샘플 → 중앙 크롭
  const scale = Math.max(WIDTH / w, HEIGHT / h);
  const rw = Math.round(w * scale), rh = Math.round(h * scale);
  execFileSync("sips", ["-z", String(rh), String(rw), src, "--out", tmp], { stdio: "ignore" });
  execFileSync("sips", ["-c", String(HEIGHT), String(WIDTH), tmp, "--out", tmp], { stdio: "ignore" });
  // sips 는 WebP 를 읽기만 지원하므로 JPEG 로 저장 (1200×900 q82 ≈ 100~200KB)
  execFileSync("sips", ["-s", "format", "jpeg", "-s", "formatOptions", String(QUALITY), tmp, "--out", outFile], { stdio: "ignore" });
  unlinkSync(tmp);
  return readFileSync(outFile);
}

console.log(`\n▶ 사진 폴더: ${PHOTO_DIR}\n▶ 출력: ${WIDTH}×${HEIGHT} JPEG q${QUALITY}${DRY ? "   (dry-run)" : ""}\n`);
const rename = {}; // oldPath → newPath
const newFiles = {}; // newName → Buffer
for (const p of plan) {
  const srcHash = createHash("sha256").update(readFileSync(p.photo)).digest("base64url").replace(/[^A-Za-z0-9]/g, "").slice(0, 8);
  const newName = `program-${p.no}-${p.slug}-${srcHash}.jpg`;
  const newPath = `/assets/${newName}`;
  if (p.oldPath === newPath) { console.log(`  = ${p.no}번 ${p.photoName}: 이미 적용됨`); continue; }
  if (DRY) { console.log(`  → ${p.no}번 ${p.photoName}  →  ${newName}   (현재 ${path.basename(p.oldPath)})`); continue; }
  const out = path.join(PUB, newName);
  const buf = convert(p.photo, out);
  newFiles[newName] = buf;
  rename[p.oldPath] = newPath;
  console.log(`  + ${p.no}번 ${p.photoName} → ${newName} (${Math.round(buf.length / 1024)} KB, 원본 ${Math.round(statSync(path.join(PUB, path.basename(p.oldPath))).size / 1024)} KB)`);
}
if (DRY || !Object.keys(rename).length) { console.log("\n변경 없음."); process.exit(0); }

// 참조 갱신: 서버·브라우저 routes, 자산 테이블
const applyRename = (s) => Object.entries(rename).reduce((acc, [o, n]) => acc.split(o).join(n), s);
for (const f of [serverRoutes, clientRoutes]) writeFileSync(f, applyRename(readFileSync(f, "utf8")));
for (const f of ["index.mjs", "index.js"].map((x) => path.join(ROOT, "server", x)).filter(existsSync)) {
  let s = readFileSync(f, "utf8");
  for (const [o, n] of Object.entries(rename)) {
    const re = new RegExp(`"${escapeRe(o)}": \\{[^}]*\\}`);
    if (!re.test(s)) fail(`${path.basename(f)} 자산 테이블에서 ${o} 항목을 찾을 수 없습니다.`);
    const buf = newFiles[path.basename(n)];
    s = s.replace(re, `"${n}": {\n\t\t"type": "image/jpeg",\n\t\t"etag": ${JSON.stringify(etagOf(buf))},\n\t\t"mtime": "${new Date().toISOString()}",\n\t\t"size": ${buf.length},\n\t\t"path": "../public${n}"\n\t}`);
  }
  writeFileSync(f, s);
}
// 옛 파일 삭제, client 미러
mkdirSync(CLI, { recursive: true });
for (const [o, n] of Object.entries(rename)) {
  for (const dir of [PUB, CLI]) { const old = path.join(dir, path.basename(o)); if (existsSync(old)) unlinkSync(old); }
  copyFileSync(path.join(PUB, path.basename(n)), path.join(CLI, path.basename(n)));
}
console.log(`\n✔ ${Object.keys(rename).length}개 이미지 교체 완료. 다음 단계: npm run data (청크 파일명·etag 갱신)\n`);
